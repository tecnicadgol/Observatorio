=== WP Chatbot KB ===
Contributors: tuempresa
Tags: chatbot, asistente virtual, IA, openai, gemini, claude, anthropic, base de conocimiento
Requires at least: 6.0
Tested up to: 6.7
Requires PHP: 8.1
Stable tag: 1.6.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Asistente virtual (chatbot) "Lexi" para WordPress que responde usando una base de conocimiento
propia, alimentada por enlaces públicos y contenido manual. Avatar animado, voz y soporte de
castellano/guaraní. Compatible con OpenAI, Google Gemini y Anthropic Claude.

== Descripción ==

WP Chatbot KB añade un widget de chat flotante (y un shortcode `[wpckb_chat]`) a tu sitio.
El asistente responde exclusivamente con información de tu propia base de conocimiento:

* Añade enlaces públicos (documentación, FAQs, políticas, páginas de producto...) y el plugin
  descarga, limpia y trocea el contenido automáticamente.
* Añade texto manualmente desde un editor sencillo en el panel de administración.
* Elige el proveedor de IA: OpenAI, Google Gemini o Anthropic Claude (arquitectura extensible
  mediante el filtro `wpckb_ai_providers` para añadir otros proveedores).
* Búsqueda semántica por embeddings con fallback automático a búsqueda por palabras clave si el
  proveedor no soporta embeddings o falla la llamada.
* Configura el prompt del sistema, la temperatura, el número de fragmentos de contexto, el
  historial de conversación, límite de mensajes por minuto y restricción por rol de usuario.
* Registro opcional de conversaciones con retención configurable.
* Claves de API cifradas en la base de datos (no se guardan en texto plano).
* Avatar animado "Lexi" (personalizable desde el admin) con saludo animado al abrir el chat.
* Entrada por voz (dictado) y lectura en voz alta de las respuestas, con botón para silenciar.
* Selector de idioma Castellano / Guaraní dentro del chat: el modelo de IA responde en el idioma
  elegido (el reconocimiento y la lectura por voz del navegador no tienen soporte fiable de
  guaraní; en ese caso el asistente sigue funcionando por texto).
* Compatible con PHP 8.1 a 8.4.

== Requisitos ==

* WordPress 6.0 o superior.
* PHP 8.1, 8.2, 8.3 u 8.4.
* Una clave de API de OpenAI, Google Gemini y/o Anthropic Claude (según el proveedor que quieras usar).

== Instalación ==

1. Sube la carpeta `wp-chatbot-kb` a `/wp-content/plugins/`.
2. Activa el plugin desde el menú "Plugins" de WordPress.
3. Ve a "Chatbot KB → Ajustes" e introduce la clave de API del proveedor que quieras usar.
4. Ve a "Chatbot KB → Base de conocimiento" y añade tus primeros enlaces o textos.
5. El widget aparecerá automáticamente en el sitio (puedes desactivarlo y usar el shortcode
   `[wpckb_chat]` en su lugar).

== Preguntas frecuentes ==

= ¿Necesito una clave de API? =
Sí. El plugin no incluye créditos de IA; debes crear una cuenta en OpenAI, Google AI Studio o
Anthropic (console.anthropic.com) y generar tu propia clave de API.

= ¿Puedo usar otro proveedor de IA distinto a OpenAI, Gemini o Claude? =
Sí. Usa el filtro de PHP `wpckb_ai_providers` para registrar una clase que implemente la
interfaz `WPCKB_AI_Provider`.

= ¿Dónde se guarda la base de conocimiento? =
En tablas propias de la base de datos de WordPress (`wp_wpckb_sources` y `wp_wpckb_chunks`),
no en el contenido público del sitio.

== Changelog ==

= 1.6.0 =
* Actualizaciones automáticas desde un repositorio público de GitHub: configurá
  "usuario/repositorio" en Ajustes → Actualizaciones automáticas y las nuevas versiones
  publicadas ahí van a aparecer en Plugins con el botón "Actualizar ahora", como cualquier
  otro plugin — ya no hace falta borrar e instalar manualmente cada vez.

= 1.5.0 =
* Selección automática de voz más cálida/femenina y de acento neutro para la lectura en voz
  alta, entre las voces disponibles en el dispositivo del visitante (heurística por nombre e
  idioma; no todos los dispositivos ofrecen las mismas voces).
* Nuevo campo "Preferencia de voz" en Ajustes → Idioma y voz, para indicar el nombre de una voz
  específica que se use cuando esté disponible.

= 1.4.0 =
* Nuevo proveedor de IA: Anthropic Claude, con la misma integración de primera clase que OpenAI
  y Gemini (selector, clave de API cifrada, modelo configurable).
* Nota: Anthropic no ofrece una API de embeddings propia; con este proveedor activo, la
  recuperación de contexto de la base de conocimiento usa automáticamente búsqueda por palabras
  clave en lugar de búsqueda semántica (el resto del asistente funciona igual).

= 1.3.0 =
* Carga masiva de URLs: pegá varias URLs a la vez (una por línea, opcionalmente "Título | URL")
  en la pantalla de Base de conocimiento para cargar en lote leyes u otras páginas.
* Instrucción explícita al modelo de IA para responder consultas por nombre popular de una ley
  (p. ej. "ley de hambre cero") indicando siempre nombre oficial, número en formato "N°/AAAA" y
  el enlace de descarga, usando la versión más recientemente publicada cuando hay ambigüedad.
* El User-Agent usado para descargar fuentes ahora se identifica como un navegador de escritorio
  habitual, ya que varios sitios oficiales bloquean con HTTP 403 a clientes que se anuncian como
  bot/script (verificado contra bacn.gov.py).

= 1.2.0 =
* Los enlaces de las fuentes citadas ahora se muestran como links clicables debajo de la
  respuesta (antes solo se indicaba la cantidad de fuentes) — clave para que el usuario pueda
  descargar el documento/ley solicitado directamente desde el chat.
* Soporte de ingesta de documentos PDF como fuente (además de páginas HTML), incluyendo
  extracción de texto y título sin dependencias externas — pensado para leyes y normativa
  publicadas como PDF.
* El modelo de IA ahora recibe instrucción explícita de no inventar URLs y de nombrar el
  documento citado para que coincida con el enlace mostrado.

= 1.1.0 =
* Avatar animado "Lexi" en el botón flotante y dentro del chat, con saludo animado configurable
  al abrir la ventana (texto + voz).
* Entrada de voz (dictado) mediante reconocimiento de voz del navegador.
* Lectura en voz alta de las respuestas (síntesis de voz), con botón de silencio.
* Selector Castellano / Guaraní en la ventana del chat; el modelo de IA responde en el idioma
  elegido.
* Nueva sección de ajustes "Idioma y voz" y "Mascota animada", con selector de archivo desde la
  librería de medios de WordPress.

= 1.0.0 =
* Versión inicial.
