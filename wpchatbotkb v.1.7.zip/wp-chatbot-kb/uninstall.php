<?php

declare(strict_types=1);

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

/**
 * Solo borra datos si el administrador activó explícitamente esta opción
 * desde los ajustes (evita pérdidas accidentales de la base de conocimiento).
 */
$settings = get_option( 'wpckb_settings', [] );

if ( empty( $settings['delete_data_on_uninstall'] ) ) {
	return;
}

global $wpdb;

$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}wpckb_chunks" );
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}wpckb_sources" );
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}wpckb_conversations" );

delete_option( 'wpckb_settings' );
delete_option( 'wpckb_db_version' );

$timestamp = wp_next_scheduled( 'wpckb_daily_maintenance' );
if ( $timestamp ) {
	wp_unschedule_event( $timestamp, 'wpckb_daily_maintenance' );
}
