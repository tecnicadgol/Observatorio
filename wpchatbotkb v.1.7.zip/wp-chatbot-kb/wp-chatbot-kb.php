<?php
/**
 * Plugin Name:       WP Chatbot KB
 * Plugin URI:         https://example.com/wp-chatbot-kb
 * Description:        Asistente virtual (chatbot) "Lexi" que responde usando una base de conocimiento propia, alimentada por enlaces públicos y contenido manual. Avatar animado, voz (dictado y lectura) y soporte de castellano/guaraní. Compatible con OpenAI, Google Gemini y Anthropic Claude.
 * Version:            1.6.0
 * Requires at least:  6.0
 * Requires PHP:       8.1
 * Author:             Tu Empresa
 * License:            GPL v2 or later
 * License URI:        https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:        wp-chatbot-kb
 * Domain Path:        /languages
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit; // No acceso directo.
}

// Requiere PHP 8.1+ (probado hasta 8.4). Aborta activación limpia si no se cumple.
if ( version_compare( PHP_VERSION, '8.1', '<' ) ) {
	add_action(
		'admin_notices',
		function (): void {
			echo '<div class="notice notice-error"><p>';
			echo esc_html__( 'WP Chatbot KB requiere PHP 8.1 o superior. Desactiva el plugin o actualiza PHP.', 'wp-chatbot-kb' );
			echo '</p></div>';
		}
	);
	return;
}

define( 'WPCKB_VERSION', '1.6.0' );
define( 'WPCKB_FILE', __FILE__ );
define( 'WPCKB_PATH', plugin_dir_path( __FILE__ ) );
define( 'WPCKB_URL', plugin_dir_url( __FILE__ ) );
define( 'WPCKB_BASENAME', plugin_basename( __FILE__ ) );

/**
 * Autoload manual de las clases del plugin (sin dependencia de Composer).
 */
spl_autoload_register(
	function ( string $class ): void {
		if ( ! str_starts_with( $class, 'WPCKB_' ) ) {
			return;
		}

		$relative = strtolower( str_replace( '_', '-', substr( $class, 6 ) ) );
		$candidates = [
			WPCKB_PATH . "includes/class-{$relative}.php",
			WPCKB_PATH . "includes/providers/class-{$relative}.php",
			WPCKB_PATH . "includes/providers/interface-{$relative}.php",
		];

		foreach ( $candidates as $file ) {
			if ( file_exists( $file ) ) {
				require_once $file;
				return;
			}
		}
	}
);

require_once WPCKB_PATH . 'includes/providers/interface-ai-provider.php';

register_activation_hook( WPCKB_FILE, [ 'WPCKB_Activator', 'activate' ] );
register_deactivation_hook( WPCKB_FILE, [ 'WPCKB_Deactivator', 'deactivate' ] );

/**
 * Arranca el plugin una vez que todos los plugins están cargados.
 */
function wpckb_run(): void {
	$plugin = new WPCKB_Plugin();
	$plugin->run();
}
add_action( 'plugins_loaded', 'wpckb_run' );
