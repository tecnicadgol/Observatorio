<?php

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Acceso a datos para fuentes (sources), fragmentos (chunks) y logs de conversación.
 */
class WPCKB_KB_Repository {

	private string $sources_table;
	private string $chunks_table;
	private string $logs_table;

	public function __construct() {
		global $wpdb;
		$this->sources_table = $wpdb->prefix . 'wpckb_sources';
		$this->chunks_table  = $wpdb->prefix . 'wpckb_chunks';
		$this->logs_table    = $wpdb->prefix . 'wpckb_conversations';
	}

	// -------------------------------------------------------------------
	// Sources
	// -------------------------------------------------------------------

	public function create_source( array $data ): int {
		global $wpdb;

		$now = current_time( 'mysql' );

		$wpdb->insert(
			$this->sources_table,
			[
				'type'         => $data['type'],
				'title'        => $data['title'] ?? '',
				'source_url'   => $data['source_url'] ?? null,
				'content_raw'  => $data['content_raw'] ?? null,
				'status'       => $data['status'] ?? 'pending',
				'created_by'   => get_current_user_id(),
				'created_at'   => $now,
				'updated_at'   => $now,
			],
			[ '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s' ]
		);

		return (int) $wpdb->insert_id;
	}

	public function update_source( int $id, array $data ): void {
		global $wpdb;
		$data['updated_at'] = current_time( 'mysql' );
		$wpdb->update( $this->sources_table, $data, [ 'id' => $id ] );
	}

	public function source_exists_by_url( string $url ): bool {
		global $wpdb;
		$count = $wpdb->get_var(
			$wpdb->prepare( "SELECT COUNT(*) FROM {$this->sources_table} WHERE source_url = %s", $url )
		);
		return (int) $count > 0;
	}

	public function get_source( int $id ): ?array {
		global $wpdb;
		$row = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$this->sources_table} WHERE id = %d", $id ),
			ARRAY_A
		);
		return $row ?: null;
	}

	public function list_sources( int $per_page = 50, int $page = 1 ): array {
		global $wpdb;
		$offset = max( 0, ( $page - 1 ) * $per_page );

		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$this->sources_table} ORDER BY created_at DESC LIMIT %d OFFSET %d",
				$per_page,
				$offset
			),
			ARRAY_A
		) ?: [];
	}

	public function count_sources(): int {
		global $wpdb;
		return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$this->sources_table}" );
	}

	public function delete_source( int $id ): void {
		global $wpdb;
		$wpdb->delete( $this->chunks_table, [ 'source_id' => $id ], [ '%d' ] );
		$wpdb->delete( $this->sources_table, [ 'id' => $id ], [ '%d' ] );
	}

	// -------------------------------------------------------------------
	// Chunks
	// -------------------------------------------------------------------

	public function replace_chunks( int $source_id, array $chunks ): void {
		global $wpdb;

		$wpdb->delete( $this->chunks_table, [ 'source_id' => $source_id ], [ '%d' ] );

		$now = current_time( 'mysql' );
		foreach ( $chunks as $index => $chunk ) {
			$wpdb->insert(
				$this->chunks_table,
				[
					'source_id'          => $source_id,
					'chunk_index'        => $index,
					'content'            => $chunk['content'],
					'embedding'          => isset( $chunk['embedding'] ) ? wp_json_encode( $chunk['embedding'] ) : null,
					'embedding_provider' => $chunk['embedding_provider'] ?? null,
					'token_estimate'     => $chunk['token_estimate'] ?? (int) ceil( mb_strlen( $chunk['content'] ) / 4 ),
					'created_at'         => $now,
				],
				[ '%d', '%d', '%s', '%s', '%s', '%d', '%s' ]
			);
		}

		$this->update_source(
			$source_id,
			[ 'chunk_count' => count( $chunks ) ]
		);
	}

	/**
	 * Devuelve todos los fragmentos con embedding disponible (para búsqueda semántica en memoria).
	 */
	public function get_all_embedded_chunks(): array {
		global $wpdb;
		return $wpdb->get_results(
			"SELECT c.id, c.source_id, c.content, c.embedding, s.title AS source_title, s.source_url
			 FROM {$this->chunks_table} c
			 INNER JOIN {$this->sources_table} s ON s.id = c.source_id
			 WHERE c.embedding IS NOT NULL AND s.status = 'ready'",
			ARRAY_A
		) ?: [];
	}

	/**
	 * Búsqueda simple por palabras clave (fallback cuando no hay embeddings disponibles).
	 */
	public function keyword_search( string $query, int $limit = 4 ): array {
		global $wpdb;

		$terms = array_filter( preg_split( '/\s+/', trim( $query ) ) ?: [] );
		$terms = array_slice( $terms, 0, 6 );

		if ( empty( $terms ) ) {
			return [];
		}

		$clauses = [];
		$values  = [];
		foreach ( $terms as $term ) {
			$clauses[] = 'c.content LIKE %s';
			$values[]  = '%' . $wpdb->esc_like( $term ) . '%';
		}

		$sql = "SELECT c.id, c.source_id, c.content, s.title AS source_title, s.source_url
				FROM {$this->chunks_table} c
				INNER JOIN {$this->sources_table} s ON s.id = c.source_id
				WHERE s.status = 'ready' AND (" . implode( ' OR ', $clauses ) . ")
				LIMIT %d";

		$values[] = $limit;

		return $wpdb->get_results( $wpdb->prepare( $sql, $values ), ARRAY_A ) ?: [];
	}

	// -------------------------------------------------------------------
	// Conversation logs
	// -------------------------------------------------------------------

	public function log_message( string $session_id, string $role, string $message ): void {
		global $wpdb;
		$wpdb->insert(
			$this->logs_table,
			[
				'session_id' => $session_id,
				'role'       => $role,
				'message'    => $message,
				'created_at' => current_time( 'mysql' ),
			],
			[ '%s', '%s', '%s', '%s' ]
		);
	}

	public function get_recent_history( string $session_id, int $turns ): array {
		global $wpdb;
		if ( $turns <= 0 ) {
			return [];
		}

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT role, message FROM {$this->logs_table}
				 WHERE session_id = %s ORDER BY id DESC LIMIT %d",
				$session_id,
				$turns * 2
			),
			ARRAY_A
		) ?: [];

		return array_reverse( $rows );
	}

	public function purge_conversations_older_than( int $days ): void {
		global $wpdb;
		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$this->logs_table} WHERE created_at < DATE_SUB(NOW(), INTERVAL %d DAY)",
				$days
			)
		);
	}

	public function count_logs(): int {
		global $wpdb;
		return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$this->logs_table}" );
	}
}
