<?php

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Renderiza el widget de chat flotante en el frontend, además del shortcode [wpckb_chat].
 */
class WPCKB_Frontend {

	public function __construct(
		private readonly WPCKB_Settings $settings
	) {
	}

	public function register_hooks(): void {
		add_shortcode( 'wpckb_chat', [ $this, 'render_shortcode' ] );
		add_action( 'wp_enqueue_scripts', [ $this, 'maybe_enqueue_assets' ] );
		add_action( 'wp_footer', [ $this, 'maybe_render_floating_widget' ] );
	}

	private function is_user_allowed( array $settings ): bool {
		if ( empty( $settings['allowed_roles'] ) ) {
			return true;
		}
		if ( ! is_user_logged_in() ) {
			return false;
		}
		$user = wp_get_current_user();
		return (bool) array_intersect( $settings['allowed_roles'], (array) $user->roles );
	}

	public function maybe_enqueue_assets(): void {
		$settings = $this->settings->get_settings();

		if ( empty( $settings['enable_widget'] ) || ! $this->is_user_allowed( $settings ) ) {
			return;
		}

		wp_enqueue_style( 'wpckb-chat-widget', WPCKB_URL . 'public/css/chat-widget.css', [], WPCKB_VERSION );
		wp_enqueue_script( 'wpckb-chat-widget', WPCKB_URL . 'public/js/chat-widget.js', [], WPCKB_VERSION, true );

		$mascot = $this->get_mascot_data( $settings );

		wp_localize_script(
			'wpckb-chat-widget',
			'WPCKB_CHAT',
			[
				'restUrl'     => esc_url_raw( rest_url( 'wpckb/v1/chat' ) ),
				'nonce'       => wp_create_nonce( 'wp_rest' ),
				'title'       => $settings['widget_title'],
				'welcome'     => [
					'es' => $settings['welcome_message'],
					'gn' => $settings['welcome_message_gn'],
				],
				'color'       => $settings['widget_color'],
				'position'    => $settings['widget_position'],
				'mascotUrl'   => $mascot['url'],
				'mascotIconUrl' => $mascot['icon_url'],
				'mascotType'  => $mascot['type'],
				'greetOnOpen' => ! empty( $settings['mascot_greet_on_open'] ),
				'enableGuarani'     => ! empty( $settings['enable_guarani'] ),
				'defaultLanguage'   => in_array( $settings['default_language'], [ 'es', 'gn' ], true ) ? $settings['default_language'] : 'es',
				'enableVoiceInput'  => ! empty( $settings['enable_voice_input'] ),
				'enableVoiceOutput' => ! empty( $settings['enable_voice_output'] ),
				'voiceNameHint'     => $settings['voice_name_hint'],
			]
		);
	}

	/**
	 * Devuelve la URL completa (escena de saludo) y la URL recortada tipo icono
	 * (botón flotante y avatar de cabecera) de la mascota configurada.
	 * Por defecto usa el personaje "Lexi" incluido con el plugin, cuyo recorte
	 * de rostro ya viene preparado; para una mascota propia subida por el
	 * administrador no se puede recortar automáticamente el rostro, así que se
	 * reutiliza la misma imagen completa (el CSS la encuadra de forma genérica).
	 */
	private function get_mascot_data( array $settings ): array {
		$attachment_id = (int) $settings['mascot_attachment_id'];

		if ( $attachment_id > 0 ) {
			$url  = wp_get_attachment_url( $attachment_id );
			$mime = get_post_mime_type( $attachment_id );

			if ( $url ) {
				$type = str_starts_with( (string) $mime, 'video/' ) ? 'video' : 'image';
				return [
					'url'      => $url,
					'icon_url' => $url,
					'type'     => $type,
				];
			}
		}

		return [
			'url'      => WPCKB_URL . 'public/img/lexi-mascot.jpeg',
			'icon_url' => WPCKB_URL . 'public/img/lexi-mascot-face.jpg',
			'type'     => 'image',
		];
	}

	public function maybe_render_floating_widget(): void {
		$settings = $this->settings->get_settings();

		if ( empty( $settings['enable_widget'] ) || ! $this->is_user_allowed( $settings ) ) {
			return;
		}

		echo '<div id="wpckb-chat-root" class="wpckb-position-' . esc_attr( $settings['widget_position'] ) . '"></div>';
	}

	public function render_shortcode(): string {
		$settings = $this->settings->get_settings();
		if ( ! $this->is_user_allowed( $settings ) ) {
			return '';
		}

		// El shortcode reutiliza el mismo contenedor; si ya existe el widget flotante
		// (misma página), evitamos duplicar el punto de montaje.
		return '<div class="wpckb-chat-inline" data-wpckb-inline="1"></div>';
	}
}
