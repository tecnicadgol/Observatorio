<?php

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Páginas de administración: Ajustes (proveedor de IA, claves, prompt, apariencia)
 * y Base de conocimiento (añadir enlaces / texto manual, listar, reintentar, borrar).
 */
class WPCKB_Admin {

	private const CAPABILITY = 'manage_options';

	public function __construct(
		private readonly WPCKB_Settings $settings,
		private readonly WPCKB_KB_Repository $repository
	) {
	}

	public function register_hooks(): void {
		add_action( 'admin_menu', [ $this, 'register_menu' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_assets' ] );

		add_action( 'admin_post_wpckb_add_url_source', [ $this, 'handle_add_url_source' ] );
		add_action( 'admin_post_wpckb_add_bulk_urls', [ $this, 'handle_add_bulk_urls' ] );
		add_action( 'admin_post_wpckb_add_manual_source', [ $this, 'handle_add_manual_source' ] );
		add_action( 'admin_post_wpckb_delete_source', [ $this, 'handle_delete_source' ] );
		add_action( 'admin_post_wpckb_reingest_source', [ $this, 'handle_reingest_source' ] );
		add_action( 'admin_notices', [ $this, 'render_admin_notices' ] );
	}

	public function register_menu(): void {
		add_menu_page(
			__( 'Chatbot KB', 'wp-chatbot-kb' ),
			__( 'Chatbot KB', 'wp-chatbot-kb' ),
			self::CAPABILITY,
			'wpckb-settings',
			[ $this, 'render_settings_page' ],
			'dashicons-format-chat',
			58
		);

		add_submenu_page(
			'wpckb-settings',
			__( 'Ajustes', 'wp-chatbot-kb' ),
			__( 'Ajustes', 'wp-chatbot-kb' ),
			self::CAPABILITY,
			'wpckb-settings',
			[ $this, 'render_settings_page' ]
		);

		add_submenu_page(
			'wpckb-settings',
			__( 'Base de conocimiento', 'wp-chatbot-kb' ),
			__( 'Base de conocimiento', 'wp-chatbot-kb' ),
			self::CAPABILITY,
			'wpckb-knowledge-base',
			[ $this, 'render_kb_page' ]
		);

		add_submenu_page(
			'wpckb-settings',
			__( 'Conversaciones', 'wp-chatbot-kb' ),
			__( 'Conversaciones', 'wp-chatbot-kb' ),
			self::CAPABILITY,
			'wpckb-conversations',
			[ $this, 'render_conversations_page' ]
		);
	}

	public function enqueue_assets( string $hook ): void {
		if ( ! str_starts_with( $hook, 'toplevel_page_wpckb' ) && ! str_contains( $hook, 'wpckb' ) ) {
			return;
		}

		wp_enqueue_style( 'wpckb-admin', WPCKB_URL . 'admin/css/admin.css', [], WPCKB_VERSION );
		wp_enqueue_media();
		wp_enqueue_script( 'wpckb-admin', WPCKB_URL . 'admin/js/admin.js', [ 'jquery' ], WPCKB_VERSION, true );
		wp_localize_script(
			'wpckb-admin',
			'WPCKB_ADMIN',
			[
				'defaultMascotUrl' => WPCKB_URL . 'public/img/lexi-mascot-face.jpg',
			]
		);
	}

	// -------------------------------------------------------------------
	// Renderizado de páginas
	// -------------------------------------------------------------------

	public function render_settings_page(): void {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			return;
		}
		$settings      = $this->settings->get_settings();
		$providers     = WPCKB_Provider_Factory::get_available_providers( $settings );
		$mascot_id     = (int) $settings['mascot_attachment_id'];
		$mascot_url    = $mascot_id ? wp_get_attachment_url( $mascot_id ) : '';
		$mascot_mime   = $mascot_id ? get_post_mime_type( $mascot_id ) : '';
		$mascot_is_default = ! $mascot_url;
		if ( $mascot_is_default ) {
			$mascot_url  = WPCKB_URL . 'public/img/lexi-mascot-face.jpg';
			$mascot_mime = 'image/jpeg';
		}
		include WPCKB_PATH . 'admin/partials/settings-page.php';
	}

	public function render_kb_page(): void {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			return;
		}
		$sources = $this->repository->list_sources( 100, 1 );
		include WPCKB_PATH . 'admin/partials/kb-page.php';
	}

	public function render_conversations_page(): void {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			return;
		}
		global $wpdb;
		$table = $wpdb->prefix . 'wpckb_conversations';
		$logs  = $wpdb->get_results( "SELECT * FROM {$table} ORDER BY id DESC LIMIT 200", ARRAY_A ) ?: [];
		include WPCKB_PATH . 'admin/partials/conversations-page.php';
	}

	// -------------------------------------------------------------------
	// Manejo de formularios (base de conocimiento)
	// -------------------------------------------------------------------

	public function handle_add_url_source(): void {
		$this->authorize_post_action( 'wpckb_kb_action' );

		$url   = esc_url_raw( trim( (string) ( $_POST['source_url'] ?? '' ) ) );
		$title = sanitize_text_field( (string) ( $_POST['title'] ?? '' ) );

		if ( '' === $url || ! wp_http_validate_url( $url ) ) {
			$this->redirect_with_notice( 'wpckb-knowledge-base', 'error', __( 'La URL no es válida.', 'wp-chatbot-kb' ) );
		}

		$source_id = $this->repository->create_source(
			[
				'type'       => 'url',
				'title'      => $title,
				'source_url' => $url,
				'status'     => 'pending',
			]
		);

		$ingestion = new WPCKB_Ingestion( $this->repository, $this->settings );
		$ingestion->ingest_url_source( $source_id );

		$this->redirect_with_notice( 'wpckb-knowledge-base', 'success', __( 'Enlace añadido y procesado.', 'wp-chatbot-kb' ) );
	}

	/**
	 * Procesa una lista de URLs pegadas en un textarea (una por línea, opcionalmente
	 * "Título | URL"). Pensado para cargar de una vez varias leyes/páginas copiadas
	 * de un listado oficial (p. ej. "Leyes por año" de BACN).
	 */
	public function handle_add_bulk_urls(): void {
		$this->authorize_post_action( 'wpckb_kb_action' );

		$raw   = (string) ( $_POST['bulk_urls'] ?? '' );
		$lines = array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', $raw ) ?: [] ) );

		if ( empty( $lines ) ) {
			$this->redirect_with_notice( 'wpckb-knowledge-base', 'error', __( 'Pegá al menos una URL.', 'wp-chatbot-kb' ) );
		}

		$max_per_batch = 30;
		$overflow      = count( $lines ) > $max_per_batch;
		$lines         = array_slice( $lines, 0, $max_per_batch );

		@set_time_limit( 0 ); // phpcs:ignore -- carga masiva: cada URL puede tardar unos segundos en descargarse y generar embeddings.

		$ingestion = new WPCKB_Ingestion( $this->repository, $this->settings );
		$added     = 0;
		$skipped   = 0;
		$failed    = 0;

		foreach ( $lines as $line ) {
			$title = '';
			$url   = $line;

			if ( str_contains( $line, '|' ) ) {
				[ $title, $url ] = array_map( 'trim', explode( '|', $line, 2 ) );
			}

			$url = esc_url_raw( $url );
			if ( '' === $url || ! wp_http_validate_url( $url ) ) {
				++$failed;
				continue;
			}

			if ( $this->repository->source_exists_by_url( $url ) ) {
				++$skipped;
				continue;
			}

			$source_id = $this->repository->create_source(
				[
					'type'       => 'url',
					'title'      => sanitize_text_field( $title ),
					'source_url' => $url,
					'status'     => 'pending',
				]
			);

			$ingestion->ingest_url_source( $source_id );

			$reingested = $this->repository->get_source( $source_id );
			if ( $reingested && 'ready' === $reingested['status'] ) {
				++$added;
			} else {
				++$failed;
			}
		}

		$message = sprintf(
			/* translators: 1: añadidas, 2: omitidas por duplicado, 3: con error */
			__( 'Carga masiva terminada: %1$d añadidas, %2$d ya existían, %3$d con error.', 'wp-chatbot-kb' ),
			$added,
			$skipped,
			$failed
		);

		if ( $overflow ) {
			$message .= ' ' . sprintf(
				/* translators: %d: límite por tanda */
				__( 'Se procesaron solo las primeras %d URLs de la lista; pegá el resto en otra tanda.', 'wp-chatbot-kb' ),
				$max_per_batch
			);
		}

		$this->redirect_with_notice( 'wpckb-knowledge-base', $failed > 0 && 0 === $added ? 'error' : 'success', $message );
	}

	public function handle_add_manual_source(): void {
		$this->authorize_post_action( 'wpckb_kb_action' );

		$title   = sanitize_text_field( (string) ( $_POST['title'] ?? '' ) );
		$content = sanitize_textarea_field( (string) ( $_POST['content'] ?? '' ) );

		if ( '' === trim( $content ) ) {
			$this->redirect_with_notice( 'wpckb-knowledge-base', 'error', __( 'El contenido no puede estar vacío.', 'wp-chatbot-kb' ) );
		}

		if ( '' === $title ) {
			$title = __( 'Nota manual', 'wp-chatbot-kb' ) . ' — ' . wp_date( 'Y-m-d H:i' );
		}

		$source_id = $this->repository->create_source(
			[
				'type'        => 'manual',
				'title'       => $title,
				'content_raw' => $content,
				'status'      => 'pending',
			]
		);

		$ingestion = new WPCKB_Ingestion( $this->repository, $this->settings );
		$ingestion->ingest_manual_source( $source_id );

		$this->redirect_with_notice( 'wpckb-knowledge-base', 'success', __( 'Contenido añadido a la base de conocimiento.', 'wp-chatbot-kb' ) );
	}

	public function handle_delete_source(): void {
		$this->authorize_get_action( 'wpckb_kb_action' );

		$id = (int) ( $_GET['id'] ?? 0 );
		if ( $id > 0 ) {
			$this->repository->delete_source( $id );
		}

		$this->redirect_with_notice( 'wpckb-knowledge-base', 'success', __( 'Fuente eliminada.', 'wp-chatbot-kb' ) );
	}

	public function handle_reingest_source(): void {
		$this->authorize_get_action( 'wpckb_kb_action' );

		$id     = (int) ( $_GET['id'] ?? 0 );
		$source = $id > 0 ? $this->repository->get_source( $id ) : null;

		if ( $source ) {
			$ingestion = new WPCKB_Ingestion( $this->repository, $this->settings );
			if ( 'url' === $source['type'] ) {
				$ingestion->ingest_url_source( $id );
			} else {
				$ingestion->ingest_manual_source( $id );
			}
		}

		$this->redirect_with_notice( 'wpckb-knowledge-base', 'success', __( 'Fuente reprocesada.', 'wp-chatbot-kb' ) );
	}

	// -------------------------------------------------------------------
	// Helpers
	// -------------------------------------------------------------------

	private function authorize_post_action( string $nonce_action ): void {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_die( esc_html__( 'No tienes permiso para realizar esta acción.', 'wp-chatbot-kb' ), 403 );
		}
		check_admin_referer( $nonce_action );
	}

	private function authorize_get_action( string $nonce_action ): void {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_die( esc_html__( 'No tienes permiso para realizar esta acción.', 'wp-chatbot-kb' ), 403 );
		}
		check_admin_referer( $nonce_action );
	}

	private function redirect_with_notice( string $page, string $type, string $message ): never {
		$url = add_query_arg(
			[
				'page'          => $page,
				'wpckb_notice'  => $type,
				'wpckb_message' => rawurlencode( $message ),
			],
			admin_url( 'admin.php' )
		);
		wp_safe_redirect( $url );
		exit;
	}

	public function render_admin_notices(): void {
		if ( empty( $_GET['wpckb_notice'] ) || empty( $_GET['wpckb_message'] ) ) {
			return;
		}

		$type    = 'error' === $_GET['wpckb_notice'] ? 'error' : 'success';
		$message = sanitize_text_field( rawurldecode( (string) $_GET['wpckb_message'] ) );

		printf(
			'<div class="notice notice-%1$s is-dismissible"><p>%2$s</p></div>',
			esc_attr( $type ),
			esc_html( $message )
		);
	}
}
