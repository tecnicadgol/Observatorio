<?php

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Se ejecuta en la activación del plugin: crea/actualiza las tablas propias.
 */
class WPCKB_Activator {

	public static function activate(): void {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$charset_collate = $wpdb->get_charset_collate();

		$sources_table = $wpdb->prefix . 'wpckb_sources';
		$chunks_table  = $wpdb->prefix . 'wpckb_chunks';
		$logs_table    = $wpdb->prefix . 'wpckb_conversations';

		$sql_sources = "CREATE TABLE {$sources_table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			type VARCHAR(20) NOT NULL DEFAULT 'url',
			title VARCHAR(255) NOT NULL DEFAULT '',
			source_url TEXT NULL,
			content_raw LONGTEXT NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'pending',
			error_message TEXT NULL,
			chunk_count INT UNSIGNED NOT NULL DEFAULT 0,
			created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			last_fetched_at DATETIME NULL,
			PRIMARY KEY  (id),
			KEY status (status),
			KEY type (type)
		) {$charset_collate};";

		$sql_chunks = "CREATE TABLE {$chunks_table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			source_id BIGINT UNSIGNED NOT NULL,
			chunk_index INT UNSIGNED NOT NULL DEFAULT 0,
			content LONGTEXT NOT NULL,
			embedding LONGTEXT NULL,
			embedding_provider VARCHAR(40) NULL,
			token_estimate INT UNSIGNED NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY source_id (source_id)
		) {$charset_collate};";

		$sql_logs = "CREATE TABLE {$logs_table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			session_id VARCHAR(64) NOT NULL,
			role VARCHAR(20) NOT NULL,
			message LONGTEXT NOT NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY session_id (session_id)
		) {$charset_collate};";

		dbDelta( $sql_sources );
		dbDelta( $sql_chunks );
		dbDelta( $sql_logs );

		update_option( 'wpckb_db_version', WPCKB_VERSION );

		if ( false === get_option( 'wpckb_settings' ) ) {
			add_option( 'wpckb_settings', WPCKB_Settings::get_defaults() );
		}

		if ( ! wp_next_scheduled( 'wpckb_daily_maintenance' ) ) {
			wp_schedule_event( time(), 'daily', 'wpckb_daily_maintenance' );
		}
	}
}
