<?php

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Expone el endpoint REST público que usa el widget de chat del frontend.
 */
class WPCKB_Chat_Controller {

	private const NAMESPACE = 'wpckb/v1';

	public function __construct(
		private readonly WPCKB_Settings $settings,
		private readonly WPCKB_KB_Repository $repository
	) {
	}

	public function register_routes(): void {
		register_rest_route(
			self::NAMESPACE,
			'/chat',
			[
				'methods'             => 'POST',
				'callback'            => [ $this, 'handle_chat' ],
				'permission_callback' => [ $this, 'check_permission' ],
				'args'                => [
					'message'    => [ 'required' => true, 'type' => 'string' ],
					'session_id' => [ 'required' => true, 'type' => 'string' ],
					'lang'       => [ 'required' => false, 'type' => 'string' ],
				],
			]
		);
	}

	public function check_permission( WP_REST_Request $request ): bool|WP_Error {
		if ( ! wp_verify_nonce( (string) $request->get_header( 'X-WP-Nonce' ), 'wp_rest' ) ) {
			return new WP_Error( 'wpckb_invalid_nonce', __( 'Sesión inválida, recarga la página.', 'wp-chatbot-kb' ), [ 'status' => 403 ] );
		}

		$settings = $this->settings->get_settings();

		if ( ! empty( $settings['allowed_roles'] ) && ! is_user_logged_in() ) {
			return new WP_Error( 'wpckb_login_required', __( 'Debes iniciar sesión para usar el asistente.', 'wp-chatbot-kb' ), [ 'status' => 401 ] );
		}

		if ( ! empty( $settings['allowed_roles'] ) && is_user_logged_in() ) {
			$user = wp_get_current_user();
			if ( ! array_intersect( $settings['allowed_roles'], (array) $user->roles ) ) {
				return new WP_Error( 'wpckb_forbidden', __( 'No tienes permiso para usar el asistente.', 'wp-chatbot-kb' ), [ 'status' => 403 ] );
			}
		}

		return true;
	}

	public function handle_chat( WP_REST_Request $request ): WP_REST_Response|WP_Error {
		$settings   = $this->settings->get_settings();
		$message    = trim( sanitize_textarea_field( (string) $request->get_param( 'message' ) ) );
		$session_id = preg_replace( '/[^a-zA-Z0-9\-]/', '', (string) $request->get_param( 'session_id' ) ) ?? '';
		$lang       = (string) $request->get_param( 'lang' );
		$lang       = ( 'gn' === $lang && ! empty( $settings['enable_guarani'] ) ) ? 'gn' : 'es';

		if ( '' === $message || mb_strlen( $message ) > 2000 ) {
			return new WP_Error( 'wpckb_invalid_message', __( 'El mensaje está vacío o es demasiado largo.', 'wp-chatbot-kb' ), [ 'status' => 400 ] );
		}

		if ( '' === $session_id ) {
			return new WP_Error( 'wpckb_invalid_session', __( 'Sesión inválida.', 'wp-chatbot-kb' ), [ 'status' => 400 ] );
		}

		$rate_limit_error = $this->check_rate_limit( $session_id, (int) $settings['rate_limit_per_minute'] );
		if ( $rate_limit_error instanceof WP_Error ) {
			return $rate_limit_error;
		}

		try {
			$provider = WPCKB_Provider_Factory::create( $settings );
		} catch ( Throwable $e ) {
			return new WP_Error( 'wpckb_provider_error', $e->getMessage(), [ 'status' => 500 ] );
		}

		if ( ! $this->settings->has_key_configured( $settings['provider'], $settings ) ) {
			return new WP_Error(
				'wpckb_missing_key',
				__( 'El asistente no está configurado todavía. Contacta al administrador del sitio.', 'wp-chatbot-kb' ),
				[ 'status' => 503 ]
			);
		}

		$retriever = new WPCKB_Retriever( $this->repository );
		$chunks    = $retriever->find_relevant_chunks( $message, $provider, (int) $settings['top_k'] );

		$messages = $this->build_messages( $settings, $session_id, $message, $chunks, $lang );

		try {
			$answer = $provider->chat(
				$messages,
				[
					'temperature' => (float) $settings['temperature'],
					'max_tokens'  => 700,
				]
			);
		} catch ( Throwable $e ) {
			return new WP_Error( 'wpckb_completion_error', $e->getMessage(), [ 'status' => 502 ] );
		}

		if ( ! empty( $settings['enable_logging'] ) ) {
			$this->repository->log_message( $session_id, 'user', $message );
			$this->repository->log_message( $session_id, 'assistant', $answer );
		}

		$sources = $this->build_sources( $chunks );

		return new WP_REST_Response(
			[
				'answer'  => $answer,
				'sources' => $sources,
			]
		);
	}

	/**
	 * Reduce los fragmentos usados como contexto a una lista de fuentes únicas
	 * (título + enlace) para que el frontend pueda mostrarlas como links
	 * clicables — p. ej. el enlace directo a la ley o proyecto de ley citado.
	 *
	 * @return array<int,array{title:string,url:string}>
	 */
	private function build_sources( array $chunks ): array {
		$seen    = [];
		$sources = [];

		foreach ( $chunks as $chunk ) {
			$url = $chunk['source_url'] ?? null;
			if ( ! $url || isset( $seen[ $url ] ) ) {
				continue;
			}
			$seen[ $url ] = true;
			$sources[]    = [
				'title' => $chunk['source_title'] ?? $url,
				'url'   => $url,
			];
		}

		return $sources;
	}

	private function build_messages( array $settings, string $session_id, string $message, array $chunks, string $lang ): array {
		$messages = [
			[ 'role' => 'system', 'content' => $settings['system_prompt'] ],
		];

		$language_instruction = 'gn' === $lang
			? 'Responde EXCLUSIVAMENTE en guaraní paraguayo (avañe\'ẽ), de forma natural y clara. No mezcles con castellano salvo términos técnicos sin traducción conocida.'
			: 'Responde EXCLUSIVAMENTE en castellano.';
		$messages[] = [ 'role' => 'system', 'content' => $language_instruction ];

		$messages[] = [
			'role'    => 'system',
			'content' => 'Si el usuario pregunta por una ley usando su nombre popular o informal (p. ej. "ley de hambre cero"), '
				. 'búscala en el CONTEXTO por ese concepto y, al identificarla, respondé siempre indicando: '
				. '(1) el nombre oficial completo de la ley, (2) su número oficial en formato "Ley N° XXXX/AAAA" '
				. '(número, seguido de una barra y el año), y (3) que el enlace para descargarla está debajo de tu respuesta. '
				. 'Si el CONTEXTO incluye varias versiones, modificaciones o leyes relacionadas con el mismo tema, usá como '
				. 'criterio la más recientemente publicada, salvo que el usuario pida explícitamente una versión anterior. '
				. 'Si no encontrás ninguna ley que coincida en el CONTEXTO, decilo con honestidad en vez de inventar un número o enlace.',
		];

		if ( ! empty( $chunks ) ) {
			$context = "CONTEXTO (extraído de la base de conocimiento del sitio). Cada fragmento indica el documento/página de origen entre corchetes.\n"
				. "El enlace exacto de cada fuente ya se muestra por separado debajo de tu respuesta, así que NO escribas URLs tú mismo (podrías inventarlas). "
				. "Cuando la pregunta trate sobre una ley, proyecto de ley u otro documento concreto, menciona su nombre o número exacto tal como aparece en el contexto, para que el usuario pueda identificar cuál de los enlaces de abajo corresponde a lo que pidió.\n\n";
			foreach ( $chunks as $i => $chunk ) {
				$n         = $i + 1;
				$doc_label = $chunk['source_title'] ?? 'documento';
				$context  .= "[{$n}] (Fuente: {$doc_label})\n" . $chunk['content'] . "\n\n";
			}
			$messages[] = [ 'role' => 'system', 'content' => $context ];
		} else {
			$messages[] = [
				'role'    => 'system',
				'content' => 'No se encontró contenido relevante en la base de conocimiento para esta pregunta. Indícaselo al usuario con honestidad.',
			];
		}

		if ( (int) $settings['max_history_turns'] > 0 ) {
			$history = $this->repository->get_recent_history( $session_id, (int) $settings['max_history_turns'] );
			foreach ( $history as $turn ) {
				$messages[] = [
					'role'    => 'assistant' === $turn['role'] ? 'assistant' : 'user',
					'content' => $turn['message'],
				];
			}
		}

		$messages[] = [ 'role' => 'user', 'content' => $message ];

		return $messages;
	}

	private function check_rate_limit( string $session_id, int $limit_per_minute ): ?WP_Error {
		$ip  = $this->get_client_ip();
		$key = 'wpckb_rl_' . md5( $ip . '|' . $session_id );

		$count = (int) get_transient( $key );
		if ( $count >= $limit_per_minute ) {
			return new WP_Error(
				'wpckb_rate_limited',
				__( 'Has enviado demasiados mensajes en poco tiempo. Espera un momento.', 'wp-chatbot-kb' ),
				[ 'status' => 429 ]
			);
		}

		set_transient( $key, $count + 1, MINUTE_IN_SECONDS );
		return null;
	}

	private function get_client_ip(): string {
		$ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
		return is_string( $ip ) ? $ip : '0.0.0.0';
	}
}
