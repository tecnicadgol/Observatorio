<?php

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Descarga contenido público desde una URL, lo limpia, lo trocea en fragmentos
 * y (si el proveedor activo lo soporta) genera sus embeddings para búsqueda semántica.
 */
class WPCKB_Ingestion {

	private const CHUNK_SIZE    = 1200; // caracteres aproximados por fragmento.
	private const CHUNK_OVERLAP = 150;
	private const MAX_CHUNKS    = 200; // límite de seguridad por fuente.

	public function __construct(
		private readonly WPCKB_KB_Repository $repository,
		private readonly WPCKB_Settings $settings
	) {
	}

	/**
	 * Descarga y procesa una fuente de tipo URL ya creada en la base de datos.
	 */
	public function ingest_url_source( int $source_id ): void {
		$source = $this->repository->get_source( $source_id );
		if ( ! $source || 'url' !== $source['type'] ) {
			return;
		}

		try {
			$fetched      = $this->fetch_url( (string) $source['source_url'] );
			$body         = $fetched['body'];
			$content_type = $fetched['content_type'];
			$title        = trim( (string) $source['title'] );

			if ( str_contains( $content_type, 'pdf' ) ) {
				$text = $this->pdf_to_text( $body );
				if ( '' === $title ) {
					$title = $this->extract_pdf_title( $body ) ?: $this->filename_from_url( (string) $source['source_url'] );
				}
				if ( '' === trim( $text ) ) {
					// PDF probablemente escaneado (sin texto extraíble): igual registramos la
					// fuente usando el título como contenido, para que el enlace directo al
					// documento quede disponible y localizable en el chat.
					$text = $title;
				}
			} else {
				$text = $this->html_to_text( $body );
				if ( '' === trim( $text ) ) {
					throw new RuntimeException( __( 'No se pudo extraer texto legible de la URL.', 'wp-chatbot-kb' ) );
				}
				if ( '' === $title ) {
					$title = $this->extract_title( $body ) ?: (string) $source['source_url'];
				}
			}

			$this->process_text( $source_id, $text );

			$this->repository->update_source(
				$source_id,
				[
					'title'           => $title,
					'content_raw'     => mb_substr( $text, 0, 500000 ),
					'status'          => 'ready',
					'error_message'   => null,
					'last_fetched_at' => current_time( 'mysql' ),
				]
			);
		} catch ( Throwable $e ) {
			$this->repository->update_source(
				$source_id,
				[
					'status'        => 'error',
					'error_message' => $e->getMessage(),
				]
			);
		}
	}

	/**
	 * Procesa contenido manual (pegado directamente por el administrador).
	 */
	public function ingest_manual_source( int $source_id ): void {
		$source = $this->repository->get_source( $source_id );
		if ( ! $source || 'manual' !== $source['type'] ) {
			return;
		}

		try {
			$this->process_text( $source_id, (string) $source['content_raw'] );
			$this->repository->update_source(
				$source_id,
				[
					'status'          => 'ready',
					'error_message'   => null,
					'last_fetched_at' => current_time( 'mysql' ),
				]
			);
		} catch ( Throwable $e ) {
			$this->repository->update_source(
				$source_id,
				[
					'status'        => 'error',
					'error_message' => $e->getMessage(),
				]
			);
		}
	}

	private function process_text( int $source_id, string $text ): void {
		$chunks_text = $this->chunk_text( $text );

		if ( empty( $chunks_text ) ) {
			throw new RuntimeException( __( 'El contenido no generó fragmentos válidos.', 'wp-chatbot-kb' ) );
		}

		$settings = $this->settings->get_settings();
		$provider = null;

		try {
			$provider = WPCKB_Provider_Factory::create( $settings );
		} catch ( Throwable ) {
			$provider = null;
		}

		$chunks = [];
		foreach ( $chunks_text as $chunk_content ) {
			$embedding = null;

			if ( $provider instanceof WPCKB_AI_Provider ) {
				$embedding = $provider->embed( $chunk_content );
			}

			$chunks[] = [
				'content'            => $chunk_content,
				'embedding'          => $embedding,
				'embedding_provider' => $embedding ? $settings['provider'] : null,
			];
		}

		$this->repository->replace_chunks( $source_id, $chunks );
	}

	/**
	 * Descarga una URL pública con cabeceras y límites razonables.
	 * Admite páginas HTML, texto plano y documentos PDF (frecuentes para leyes
	 * y normativa oficial).
	 *
	 * @return array{body:string,content_type:string}
	 */
	private function fetch_url( string $url ): array {
		if ( ! wp_http_validate_url( $url ) ) {
			throw new RuntimeException( __( 'La URL proporcionada no es válida o no es accesible públicamente.', 'wp-chatbot-kb' ) );
		}

		$response = wp_remote_get(
			$url,
			[
				'timeout'     => 30,
				'redirection' => 3,
				// Algunos sitios oficiales (p. ej. con protección anti-bot tipo WAF) rechazan
				// user-agents que se identifican como script/bot; nos anunciamos como un
				// navegador de escritorio habitual para poder descargar contenido público.
				'user-agent'  => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36',
				'headers'     => [
					'Accept' => 'text/html,application/xhtml+xml,application/xml;q=0.9,application/pdf,*/*;q=0.8',
				],
			]
		);

		if ( is_wp_error( $response ) ) {
			throw new RuntimeException( esc_html( $response->get_error_message() ) );
		}

		$code = wp_remote_retrieve_response_code( $response );
		if ( $code < 200 || $code >= 300 ) {
			throw new RuntimeException( esc_html( "No se pudo descargar la URL (HTTP {$code})." ) );
		}

		$content_type = (string) wp_remote_retrieve_header( $response, 'content-type' );
		$is_supported = '' === $content_type
			|| str_contains( $content_type, 'text/html' )
			|| str_contains( $content_type, 'text/plain' )
			|| str_contains( $content_type, 'pdf' );

		if ( ! $is_supported ) {
			throw new RuntimeException( __( 'Solo se admiten páginas HTML, texto plano o PDF por ahora.', 'wp-chatbot-kb' ) );
		}

		return [
			'body'         => wp_remote_retrieve_body( $response ),
			'content_type' => $content_type,
		];
	}

	private function extract_title( string $html ): ?string {
		if ( preg_match( '/<title[^>]*>(.*?)<\/title>/is', $html, $matches ) ) {
			return trim( wp_strip_all_tags( html_entity_decode( $matches[1] ) ) );
		}
		return null;
	}

	/**
	 * Extractor de texto de PDF minimalista, sin dependencias externas: localiza
	 * los streams de contenido (descomprimiendo FlateDecode) y recupera las
	 * cadenas de texto de los operadores Tj/TJ. No maneja PDFs escaneados
	 * (sin capa de texto) ni todos los filtros de compresión, pero es
	 * suficiente para la mayoría de documentos oficiales generados desde
	 * Word/LibreOffice/LaTeX (leyes, resoluciones, proyectos de ley, etc.).
	 */
	private function pdf_to_text( string $data ): string {
		if ( ! preg_match_all( '/<<(.*?)>>\s*stream\r?\n(.*?)\r?\n?endstream/s', $data, $matches, PREG_SET_ORDER ) ) {
			return '';
		}

		$text = '';
		foreach ( $matches as $match ) {
			$dict   = $match[1];
			$stream = $match[2];

			if ( str_contains( $dict, 'FlateDecode' ) ) {
				$decoded = @gzuncompress( $stream );
				if ( false === $decoded ) {
					$decoded = @gzinflate( substr( $stream, 2 ) );
				}
				if ( false === $decoded ) {
					continue;
				}
				$stream = $decoded;
			} elseif ( str_contains( $dict, '/Filter' ) ) {
				// Filtro no soportado (imagen, JPXDecode, DCTDecode, etc.): se omite.
				continue;
			}

			if ( preg_match_all( '/\((?:\\\\.|[^()\\\\])*\)/s', $stream, $strings ) ) {
				foreach ( $strings[0] as $raw_string ) {
					$text .= $this->decode_pdf_string( $raw_string ) . ' ';
				}
			}
			$text .= "\n";
		}

		$text = trim( preg_replace( '/[ \t]+/', ' ', $text ) ?? $text );

		// Algunas fuentes de PDF usan codificaciones propias sin tabla ToUnicode,
		// lo que puede producir bytes UTF-8 inválidos: se limpian para evitar
		// errores al guardar en la base de datos.
		return wp_check_invalid_utf8( $text, true );
	}

	/**
	 * Intenta leer /Title desde el diccionario /Info del PDF (no comprimido en
	 * la mayoría de los casos). Soporta tanto cadenas literales como hexadecimales.
	 */
	private function extract_pdf_title( string $data ): ?string {
		if ( preg_match( '/\/Title\s*\(((?:\\\\.|[^()\\\\])*)\)/s', $data, $matches ) ) {
			$title = trim( wp_check_invalid_utf8( $this->decode_pdf_string( '(' . $matches[1] . ')' ), true ) );
			return '' !== $title ? $title : null;
		}

		if ( preg_match( '/\/Title\s*<([0-9A-Fa-f\s]+)>/', $data, $matches ) ) {
			$bytes = @hex2bin( preg_replace( '/\s+/', '', $matches[1] ) ?? '' );
			if ( false !== $bytes && '' !== $bytes ) {
				if ( str_starts_with( $bytes, "\xFE\xFF" ) ) {
					$decoded = @mb_convert_encoding( substr( $bytes, 2 ), 'UTF-8', 'UTF-16BE' );
					return $decoded ? trim( wp_check_invalid_utf8( $decoded, true ) ) : null;
				}
				return trim( wp_check_invalid_utf8( $bytes, true ) ) ?: null;
			}
		}

		return null;
	}

	/**
	 * Decodifica una cadena literal de PDF "(texto \\)escapado)" a texto plano.
	 */
	private function decode_pdf_string( string $raw ): string {
		$inner = substr( $raw, 1, -1 );

		return preg_replace_callback(
			'/\\\\([nrtbf()\\\\]|[0-7]{1,3})/',
			static function ( array $m ): string {
				return match ( $m[1][0] ) {
					'n'     => "\n",
					'r'     => "\r",
					't'     => "\t",
					'b'     => "\x08",
					'f'     => "\x0C",
					'(', ')', '\\' => $m[1],
					default => chr( (int) octdec( $m[1] ) ),
				};
			},
			$inner
		) ?? $inner;
	}

	/**
	 * Deriva un título legible a partir del nombre de archivo de la URL,
	 * usado como último recurso cuando no hay título en el PDF ni lo indicó el administrador.
	 */
	private function filename_from_url( string $url ): string {
		$path = (string) wp_parse_url( $url, PHP_URL_PATH );
		$name = rawurldecode( basename( $path ) );
		$name = preg_replace( '/\.[a-zA-Z0-9]{1,5}$/', '', $name ) ?? $name;
		$name = trim( str_replace( [ '-', '_' ], ' ', $name ) );

		return '' !== $name ? $name : $url;
	}

	/**
	 * Convierte HTML en texto plano legible, descartando scripts, estilos y navegación.
	 */
	private function html_to_text( string $html ): string {
		$html = preg_replace( '/<(script|style|noscript|svg|nav|footer|header)[^>]*>.*?<\/\1>/is', ' ', $html ) ?? $html;
		$html = preg_replace( '/<!--.*?-->/s', ' ', $html ) ?? $html;
		$text = wp_strip_all_tags( $html, true );
		$text = html_entity_decode( $text, ENT_QUOTES );
		$text = preg_replace( '/[ \t]+/', ' ', $text ) ?? $text;
		$text = preg_replace( '/\n{3,}/', "\n\n", $text ) ?? $text;

		return trim( $text );
	}

	/**
	 * Trocea el texto en fragmentos de tamaño manejable, con solapamiento,
	 * intentando cortar en límites de frase/párrafo cuando sea posible.
	 *
	 * @return string[]
	 */
	private function chunk_text( string $text ): array {
		$text = trim( $text );
		if ( '' === $text ) {
			return [];
		}

		$length = mb_strlen( $text );
		if ( $length <= self::CHUNK_SIZE ) {
			return [ $text ];
		}

		$chunks = [];
		$start  = 0;

		while ( $start < $length && count( $chunks ) < self::MAX_CHUNKS ) {
			$end = min( $start + self::CHUNK_SIZE, $length );

			if ( $end < $length ) {
				$slice        = mb_substr( $text, $start, self::CHUNK_SIZE );
				$break_point  = max(
					mb_strrpos( $slice, "\n\n" ) ?: 0,
					mb_strrpos( $slice, '. ' ) ?: 0
				);
				if ( $break_point > (int) ( self::CHUNK_SIZE * 0.4 ) ) {
					$end = $start + $break_point + 1;
				}
			}

			$chunk = trim( mb_substr( $text, $start, $end - $start ) );
			if ( '' !== $chunk ) {
				$chunks[] = $chunk;
			}

			if ( $end >= $length ) {
				break;
			}

			$start = max( $end - self::CHUNK_OVERLAP, $start + 1 );
		}

		return $chunks;
	}
}
