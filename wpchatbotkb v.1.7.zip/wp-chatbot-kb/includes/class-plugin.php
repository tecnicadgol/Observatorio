<?php

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Orquestador principal: registra admin, REST API, shortcode y assets públicos.
 */
final class WPCKB_Plugin {

	private WPCKB_Settings $settings;
	private WPCKB_KB_Repository $repository;

	public function __construct() {
		$this->settings   = new WPCKB_Settings();
		$this->repository = new WPCKB_KB_Repository();
	}

	public function run(): void {
		load_plugin_textdomain( 'wp-chatbot-kb', false, dirname( WPCKB_BASENAME ) . '/languages' );

		$this->settings->register_hooks();

		$updater = new WPCKB_Updater( $this->settings );
		$updater->register_hooks();

		if ( is_admin() ) {
			$admin = new WPCKB_Admin( $this->settings, $this->repository );
			$admin->register_hooks();
		}

		$chat_controller = new WPCKB_Chat_Controller( $this->settings, $this->repository );
		add_action( 'rest_api_init', [ $chat_controller, 'register_routes' ] );

		$frontend = new WPCKB_Frontend( $this->settings );
		$frontend->register_hooks();

		add_action( 'wpckb_daily_maintenance', [ $this, 'run_daily_maintenance' ] );
	}

	public function run_daily_maintenance(): void {
		// Purga logs de conversación más antiguos que la retención configurada.
		$settings = $this->settings->get_settings();
		$days     = max( 0, (int) ( $settings['log_retention_days'] ?? 30 ) );

		if ( $days > 0 ) {
			$this->repository->purge_conversations_older_than( $days );
		}
	}
}
