<?php

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Gestiona la opción wpckb_settings: valores por defecto, sanitización y
 * cifrado/descifrado de las claves de API (no se guardan en texto plano).
 */
class WPCKB_Settings {

	public const OPTION_KEY = 'wpckb_settings';

	public static function get_defaults(): array {
		return [
			'provider'               => 'openai',
			'openai_api_key'         => '',
			'openai_chat_model'      => 'gpt-4o-mini',
			'openai_embedding_model' => 'text-embedding-3-small',
			'gemini_api_key'         => '',
			'gemini_chat_model'      => 'gemini-2.0-flash',
			'gemini_embedding_model' => 'text-embedding-004',
			'anthropic_api_key'      => '',
			'anthropic_chat_model'   => 'claude-sonnet-5',
			'system_prompt'          => "Eres un asistente virtual útil y honesto. Responde ÚNICAMENTE con base en el CONTEXTO proporcionado, que proviene de la base de conocimiento del sitio. Si la respuesta no está en el contexto, indica claramente que no dispones de esa información y sugiere contactar a soporte.",
			'welcome_message'        => 'Hola, ¿en qué puedo ayudarte?',
			'welcome_message_gn'     => 'Mba\'éichapa, mba\'épa aikotevẽ ndéve?',
			'widget_title'           => 'Asistente virtual',
			'widget_color'           => '#2563eb',
			'widget_position'        => 'bottom-right',
			'top_k'                  => 4,
			'max_history_turns'      => 6,
			'temperature'            => 0.3,
			'enable_widget'          => true,
			'enable_logging'         => true,
			'log_retention_days'     => 30,
			'rate_limit_per_minute'  => 10,
			'allowed_roles'          => [],
			'delete_data_on_uninstall' => false,
			// Idiomas.
			'default_language'       => 'es',
			'enable_guarani'         => true,
			// Voz.
			'enable_voice_input'     => true,
			'enable_voice_output'    => true,
			'voice_name_hint'        => '',
			// Mascota / avatar animado.
			'mascot_attachment_id'   => 0,
			'mascot_greet_on_open'   => true,
			// Actualizaciones automáticas.
			'update_repo'            => '',
		];
	}

	public function register_hooks(): void {
		add_action( 'admin_init', [ $this, 'register_setting' ] );
	}

	public function register_setting(): void {
		register_setting(
			'wpckb_settings_group',
			self::OPTION_KEY,
			[
				'type'              => 'array',
				'sanitize_callback' => [ $this, 'sanitize' ],
				'default'           => self::get_defaults(),
			]
		);
	}

	/**
	 * Devuelve los ajustes ya fusionados con los valores por defecto,
	 * con las claves de API descifradas y listas para usarse en memoria.
	 */
	public function get_settings(): array {
		$stored = get_option( self::OPTION_KEY, [] );
		if ( ! is_array( $stored ) ) {
			$stored = [];
		}

		$settings = array_merge( self::get_defaults(), $stored );

		foreach ( [ 'openai_api_key', 'gemini_api_key', 'anthropic_api_key' ] as $key ) {
			$settings[ $key ] = $this->decrypt( (string) ( $settings[ $key ] ?? '' ) );
		}

		return $settings;
	}

	/**
	 * Sanitiza el array recibido del formulario de opciones y cifra las claves de API.
	 */
	public function sanitize( $input ): array {
		$existing = get_option( self::OPTION_KEY, [] );
		if ( ! is_array( $existing ) ) {
			$existing = [];
		}
		$defaults = self::get_defaults();
		$output   = array_merge( $defaults, $existing );

		if ( ! is_array( $input ) ) {
			return $output;
		}

		$output['provider']               = in_array( $input['provider'] ?? '', [ 'openai', 'gemini', 'anthropic' ], true ) ? $input['provider'] : $defaults['provider'];
		$output['openai_chat_model']      = sanitize_text_field( $input['openai_chat_model'] ?? $defaults['openai_chat_model'] );
		$output['openai_embedding_model'] = sanitize_text_field( $input['openai_embedding_model'] ?? $defaults['openai_embedding_model'] );
		$output['gemini_chat_model']      = sanitize_text_field( $input['gemini_chat_model'] ?? $defaults['gemini_chat_model'] );
		$output['gemini_embedding_model'] = sanitize_text_field( $input['gemini_embedding_model'] ?? $defaults['gemini_embedding_model'] );
		$output['anthropic_chat_model']   = sanitize_text_field( $input['anthropic_chat_model'] ?? $defaults['anthropic_chat_model'] );
		$output['system_prompt']          = sanitize_textarea_field( $input['system_prompt'] ?? $defaults['system_prompt'] );
		$output['welcome_message']        = sanitize_text_field( $input['welcome_message'] ?? $defaults['welcome_message'] );
		$output['welcome_message_gn']     = sanitize_text_field( $input['welcome_message_gn'] ?? $defaults['welcome_message_gn'] );
		$output['widget_title']           = sanitize_text_field( $input['widget_title'] ?? $defaults['widget_title'] );
		$output['widget_color']           = sanitize_hex_color( $input['widget_color'] ?? $defaults['widget_color'] ) ?: $defaults['widget_color'];
		$output['widget_position']        = in_array( $input['widget_position'] ?? '', [ 'bottom-right', 'bottom-left' ], true ) ? $input['widget_position'] : $defaults['widget_position'];
		$output['top_k']                  = max( 1, min( 10, (int) ( $input['top_k'] ?? $defaults['top_k'] ) ) );
		$output['max_history_turns']      = max( 0, min( 20, (int) ( $input['max_history_turns'] ?? $defaults['max_history_turns'] ) ) );
		$output['temperature']            = max( 0, min( 2, (float) ( $input['temperature'] ?? $defaults['temperature'] ) ) );
		$output['enable_widget']          = ! empty( $input['enable_widget'] );
		$output['enable_logging']         = ! empty( $input['enable_logging'] );
		$output['log_retention_days']     = max( 0, min( 365, (int) ( $input['log_retention_days'] ?? $defaults['log_retention_days'] ) ) );
		$output['rate_limit_per_minute']  = max( 1, min( 120, (int) ( $input['rate_limit_per_minute'] ?? $defaults['rate_limit_per_minute'] ) ) );

		$allowed_roles = $input['allowed_roles'] ?? [];
		$output['allowed_roles'] = is_array( $allowed_roles ) ? array_map( 'sanitize_key', $allowed_roles ) : [];
		$output['delete_data_on_uninstall'] = ! empty( $input['delete_data_on_uninstall'] );

		$output['default_language']    = in_array( $input['default_language'] ?? '', [ 'es', 'gn' ], true ) ? $input['default_language'] : $defaults['default_language'];
		$output['enable_guarani']      = ! empty( $input['enable_guarani'] );
		$output['enable_voice_input']  = ! empty( $input['enable_voice_input'] );
		$output['enable_voice_output'] = ! empty( $input['enable_voice_output'] );
		$output['voice_name_hint']     = sanitize_text_field( $input['voice_name_hint'] ?? $defaults['voice_name_hint'] );
		$output['mascot_greet_on_open'] = ! empty( $input['mascot_greet_on_open'] );
		$output['mascot_attachment_id'] = max( 0, (int) ( $input['mascot_attachment_id'] ?? $defaults['mascot_attachment_id'] ) );

		$repo = sanitize_text_field( $input['update_repo'] ?? $defaults['update_repo'] );
		$output['update_repo'] = preg_match( '#^[\w.-]+/[\w.-]+$#', $repo ) ? $repo : '';

		// Las claves de API solo se sobrescriben si el usuario escribió algo nuevo
		// (el campo se muestra vacío/enmascarado en pantalla por seguridad).
		if ( ! empty( $input['openai_api_key'] ) ) {
			$output['openai_api_key'] = $this->encrypt( sanitize_text_field( $input['openai_api_key'] ) );
		}
		if ( ! empty( $input['gemini_api_key'] ) ) {
			$output['gemini_api_key'] = $this->encrypt( sanitize_text_field( $input['gemini_api_key'] ) );
		}
		if ( ! empty( $input['anthropic_api_key'] ) ) {
			$output['anthropic_api_key'] = $this->encrypt( sanitize_text_field( $input['anthropic_api_key'] ) );
		}

		if ( ! empty( $input['clear_openai_api_key'] ) ) {
			$output['openai_api_key'] = '';
		}
		if ( ! empty( $input['clear_gemini_api_key'] ) ) {
			$output['gemini_api_key'] = '';
		}
		if ( ! empty( $input['clear_anthropic_api_key'] ) ) {
			$output['anthropic_api_key'] = '';
		}

		return $output;
	}

	public function has_key_configured( string $provider, ?array $settings = null ): bool {
		$settings = $settings ?? $this->get_settings();
		return '' !== trim( (string) ( $settings[ "{$provider}_api_key" ] ?? '' ) );
	}

	/**
	 * Cifrado reversible ligero basado en las claves de sal de WordPress.
	 * No sustituye a un gestor de secretos dedicado, pero evita guardar
	 * las claves de API en texto plano dentro de wp_options.
	 */
	private function encryption_key(): string {
		$secret = defined( 'AUTH_KEY' ) && AUTH_KEY ? AUTH_KEY : 'wpckb-fallback-secret';
		return hash( 'sha256', $secret, true );
	}

	public function encrypt( string $value ): string {
		if ( '' === $value || ! function_exists( 'openssl_encrypt' ) ) {
			return $value;
		}

		$iv        = random_bytes( 16 );
		$encrypted = openssl_encrypt( $value, 'aes-256-cbc', $this->encryption_key(), OPENSSL_RAW_DATA, $iv );

		if ( false === $encrypted ) {
			return $value;
		}

		return 'enc:' . base64_encode( $iv . $encrypted );
	}

	public function decrypt( string $value ): string {
		if ( ! str_starts_with( $value, 'enc:' ) || ! function_exists( 'openssl_decrypt' ) ) {
			return $value;
		}

		$raw = base64_decode( substr( $value, 4 ), true );
		if ( false === $raw || strlen( $raw ) < 17 ) {
			return '';
		}

		$iv         = substr( $raw, 0, 16 );
		$ciphertext = substr( $raw, 16 );
		$decrypted  = openssl_decrypt( $ciphertext, 'aes-256-cbc', $this->encryption_key(), OPENSSL_RAW_DATA, $iv );

		return false === $decrypted ? '' : $decrypted;
	}
}
