<?php

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Se ejecuta en la desactivación. No borra datos ni tablas (eso lo hace uninstall.php si procede).
 */
class WPCKB_Deactivator {

	public static function deactivate(): void {
		$timestamp = wp_next_scheduled( 'wpckb_daily_maintenance' );
		if ( $timestamp ) {
			wp_unschedule_event( $timestamp, 'wpckb_daily_maintenance' );
		}
	}
}
