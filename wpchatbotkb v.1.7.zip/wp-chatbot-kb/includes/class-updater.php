<?php

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Actualizaciones automáticas del plugin desde un repositorio público de GitHub,
 * sin depender del repositorio oficial de WordPress.org. Usa la API de
 * "Releases" de GitHub: cada nueva versión se publica ahí con un tag
 * "X.Y.Z" (o "vX.Y.Z"). Si el release tiene un archivo .zip adjunto se usa
 * ese; si no, se usa el .zip de código fuente que GitHub genera
 * automáticamente para el tag.
 */
class WPCKB_Updater {

	private const CACHE_PREFIX = 'wpckb_github_release_';
	private const CACHE_TTL    = 6 * HOUR_IN_SECONDS;

	public function __construct(
		private readonly WPCKB_Settings $settings
	) {
	}

	public function register_hooks(): void {
		add_filter( 'pre_set_site_transient_update_plugins', [ $this, 'inject_update' ] );
		add_filter( 'plugins_api', [ $this, 'plugin_info' ], 20, 3 );
		add_filter( 'upgrader_source_selection', [ $this, 'fix_source_folder' ], 10, 4 );
		add_action( 'upgrader_process_complete', [ $this, 'clear_cache_after_update' ], 10, 2 );
	}

	private function repo_slug(): string {
		$settings = $this->settings->get_settings();
		return trim( (string) ( $settings['update_repo'] ?? '' ), " \t\n\r\0\x0B/" );
	}

	/**
	 * @return array{version:string,download_url:string,changelog:string,html_url:string}|null
	 */
	private function get_latest_release(): ?array {
		$repo = $this->repo_slug();
		if ( '' === $repo || ! str_contains( $repo, '/' ) ) {
			return null;
		}

		$cache_key = self::CACHE_PREFIX . md5( $repo );
		$cached    = get_transient( $cache_key );
		if ( is_array( $cached ) ) {
			return $cached ?: null;
		}

		$response = wp_remote_get(
			"https://api.github.com/repos/{$repo}/releases/latest",
			[
				'timeout' => 15,
				'headers' => [ 'Accept' => 'application/vnd.github+json' ],
			]
		);

		if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
			set_transient( $cache_key, [], self::CACHE_TTL );
			return null;
		}

		$data = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( ! is_array( $data ) || empty( $data['tag_name'] ) ) {
			set_transient( $cache_key, [], self::CACHE_TTL );
			return null;
		}

		$download_url = '';
		if ( ! empty( $data['assets'][0]['browser_download_url'] ) ) {
			$download_url = (string) $data['assets'][0]['browser_download_url'];
		} elseif ( ! empty( $data['zipball_url'] ) ) {
			$download_url = (string) $data['zipball_url'];
		}

		$release = [
			'version'      => ltrim( (string) $data['tag_name'], 'vV' ),
			'download_url' => $download_url,
			'changelog'    => (string) ( $data['body'] ?? '' ),
			'html_url'     => (string) ( $data['html_url'] ?? '' ),
		];

		set_transient( $cache_key, $release, self::CACHE_TTL );

		return $release;
	}

	/**
	 * @param mixed $transient
	 * @return mixed
	 */
	public function inject_update( $transient ) {
		if ( empty( $transient->checked ) ) {
			return $transient;
		}

		$release = $this->get_latest_release();
		if ( ! $release || '' === $release['download_url'] ) {
			return $transient;
		}

		if ( ! version_compare( $release['version'], WPCKB_VERSION, '>' ) ) {
			return $transient;
		}

		$transient->response[ WPCKB_BASENAME ] = (object) [
			'slug'        => dirname( WPCKB_BASENAME ),
			'plugin'      => WPCKB_BASENAME,
			'new_version' => $release['version'],
			'url'         => $release['html_url'] ?: ( 'https://github.com/' . $this->repo_slug() ),
			'package'     => $release['download_url'],
			'tested'      => get_bloginfo( 'version' ),
		];

		return $transient;
	}

	/**
	 * @param mixed  $result
	 * @param string $action
	 * @param mixed  $args
	 * @return mixed
	 */
	public function plugin_info( $result, $action, $args ) {
		if ( 'plugin_information' !== $action || ! is_object( $args ) || empty( $args->slug ) || dirname( WPCKB_BASENAME ) !== $args->slug ) {
			return $result;
		}

		$release = $this->get_latest_release();
		if ( ! $release ) {
			return $result;
		}

		return (object) [
			'name'          => 'WP Chatbot KB',
			'slug'          => dirname( WPCKB_BASENAME ),
			'version'       => $release['version'],
			'download_link' => $release['download_url'],
			'sections'      => [
				'changelog' => wpautop( esc_html( $release['changelog'] ) ),
			],
		];
	}

	/**
	 * GitHub empaqueta el zip con una carpeta raíz distinta al slug del plugin
	 * (p. ej. "repo-1.6.0/"); la renombramos para que WordPress reconozca la
	 * actualización como la misma instalación en vez de crear una carpeta nueva.
	 *
	 * @param mixed $source
	 * @param mixed $remote_source
	 * @param mixed $upgrader
	 * @return mixed
	 */
	public function fix_source_folder( $source, $remote_source, $upgrader, $hook_extra = [] ) {
		global $wp_filesystem;

		if ( empty( $hook_extra['plugin'] ) || WPCKB_BASENAME !== $hook_extra['plugin'] || ! $wp_filesystem ) {
			return $source;
		}

		$desired = trailingslashit( $remote_source ) . dirname( WPCKB_BASENAME );

		if ( untrailingslashit( $source ) === untrailingslashit( $desired ) ) {
			return $source;
		}

		if ( $wp_filesystem->move( $source, $desired, true ) ) {
			return trailingslashit( $desired );
		}

		return $source;
	}

	/**
	 * @param mixed $upgrader
	 */
	public function clear_cache_after_update( $upgrader, array $hook_extra ): void {
		if ( 'update' === ( $hook_extra['action'] ?? '' ) && 'plugin' === ( $hook_extra['type'] ?? '' ) ) {
			$repo = $this->repo_slug();
			if ( '' !== $repo ) {
				delete_transient( self::CACHE_PREFIX . md5( $repo ) );
			}
		}
	}
}
