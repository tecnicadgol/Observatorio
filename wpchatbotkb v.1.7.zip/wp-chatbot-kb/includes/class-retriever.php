<?php

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Recupera los fragmentos de la base de conocimiento más relevantes para una pregunta.
 * Usa similitud de coseno sobre embeddings cuando están disponibles; si no,
 * cae a una búsqueda por palabras clave (LIKE) para que el plugin siga funcionando
 * incluso sin soporte de embeddings.
 */
class WPCKB_Retriever {

	public function __construct(
		private readonly WPCKB_KB_Repository $repository
	) {
	}

	/**
	 * @return array<int,array{content:string,source_title:string,source_url:?string}>
	 */
	public function find_relevant_chunks( string $query, WPCKB_AI_Provider $provider, int $top_k ): array {
		$query_embedding = null;

		try {
			$query_embedding = $provider->embed( $query );
		} catch ( Throwable ) {
			$query_embedding = null;
		}

		if ( null !== $query_embedding ) {
			$results = $this->semantic_search( $query_embedding, $top_k );
			if ( ! empty( $results ) ) {
				return $results;
			}
		}

		return array_map(
			static fn ( array $row ): array => [
				'content'      => $row['content'],
				'source_title' => $row['source_title'],
				'source_url'   => $row['source_url'],
			],
			$this->repository->keyword_search( $query, $top_k )
		);
	}

	private function semantic_search( array $query_embedding, int $top_k ): array {
		$rows = $this->repository->get_all_embedded_chunks();
		if ( empty( $rows ) ) {
			return [];
		}

		$scored = [];
		foreach ( $rows as $row ) {
			$embedding = json_decode( (string) $row['embedding'], true );
			if ( ! is_array( $embedding ) || empty( $embedding ) ) {
				continue;
			}

			$score = $this->cosine_similarity( $query_embedding, $embedding );
			$scored[] = [
				'score'        => $score,
				'content'      => $row['content'],
				'source_title' => $row['source_title'],
				'source_url'   => $row['source_url'],
			];
		}

		usort( $scored, static fn ( array $a, array $b ): int => $b['score'] <=> $a['score'] );

		$top = array_slice( $scored, 0, $top_k );

		// Filtra resultados con muy baja relevancia para no "alucinar" contexto irrelevante.
		return array_values(
			array_filter( $top, static fn ( array $row ): bool => $row['score'] > 0.15 )
		);
	}

	private function cosine_similarity( array $a, array $b ): float {
		$length = min( count( $a ), count( $b ) );
		if ( 0 === $length ) {
			return 0.0;
		}

		$dot = 0.0;
		$mag_a = 0.0;
		$mag_b = 0.0;

		for ( $i = 0; $i < $length; $i++ ) {
			$dot   += $a[ $i ] * $b[ $i ];
			$mag_a += $a[ $i ] ** 2;
			$mag_b += $b[ $i ] ** 2;
		}

		if ( 0.0 === $mag_a || 0.0 === $mag_b ) {
			return 0.0;
		}

		return $dot / ( sqrt( $mag_a ) * sqrt( $mag_b ) );
	}
}
