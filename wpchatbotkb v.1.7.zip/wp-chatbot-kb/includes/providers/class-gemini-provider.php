<?php

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Proveedor Google Gemini (generateContent + embedContent) vía Generative Language API.
 * El nombre del modelo es configurable en pantalla, por lo que funciona con
 * cualquier versión disponible (gemini-2.0-flash, gemini-1.5-pro, futuras versiones, etc.).
 */
final class WPCKB_Gemini_Provider implements WPCKB_AI_Provider {

	private const BASE_URL = 'https://generativelanguage.googleapis.com/v1beta/models/';

	public function __construct(
		private readonly string $api_key,
		private readonly string $chat_model,
		private readonly string $embedding_model
	) {
	}

	public function get_slug(): string {
		return 'gemini';
	}

	public function get_label(): string {
		return 'Google Gemini';
	}

	public function chat( array $messages, array $options = [] ): string {
		if ( '' === $this->api_key ) {
			throw new RuntimeException( __( 'No se ha configurado la clave de API de Gemini.', 'wp-chatbot-kb' ) );
		}

		[ $system_instruction, $contents ] = $this->to_gemini_format( $messages );

		$body = [
			'contents'         => $contents,
			'generationConfig' => [
				'temperature'     => $options['temperature'] ?? 0.3,
				'maxOutputTokens' => $options['max_tokens'] ?? 600,
			],
		];

		if ( null !== $system_instruction ) {
			$body['systemInstruction'] = [
				'parts' => [ [ 'text' => $system_instruction ] ],
			];
		}

		$url = self::BASE_URL . rawurlencode( $this->chat_model ) . ':generateContent?key=' . rawurlencode( $this->api_key );

		$response = wp_remote_post(
			$url,
			[
				'timeout' => 30,
				'headers' => [ 'Content-Type' => 'application/json' ],
				'body'    => wp_json_encode( $body ),
			]
		);

		$data = $this->parse_response( $response );

		$text = $data['candidates'][0]['content']['parts'][0]['text'] ?? null;
		if ( ! is_string( $text ) || '' === trim( $text ) ) {
			$block_reason = $data['promptFeedback']['blockReason'] ?? null;
			if ( $block_reason ) {
				throw new RuntimeException( esc_html( "Gemini bloqueó la respuesta: {$block_reason}" ) );
			}
			throw new RuntimeException( __( 'Gemini devolvió una respuesta vacía.', 'wp-chatbot-kb' ) );
		}

		return trim( $text );
	}

	public function embed( string $text ): ?array {
		if ( '' === $this->api_key || '' === trim( $text ) ) {
			return null;
		}

		$url = self::BASE_URL . rawurlencode( $this->embedding_model ) . ':embedContent?key=' . rawurlencode( $this->api_key );

		$response = wp_remote_post(
			$url,
			[
				'timeout' => 20,
				'headers' => [ 'Content-Type' => 'application/json' ],
				'body'    => wp_json_encode(
					[
						'model'   => 'models/' . $this->embedding_model,
						'content' => [
							'parts' => [ [ 'text' => mb_substr( $text, 0, 8000 ) ] ],
						],
					]
				),
			]
		);

		try {
			$data = $this->parse_response( $response );
		} catch ( RuntimeException ) {
			return null;
		}

		$vector = $data['embedding']['values'] ?? null;
		return is_array( $vector ) ? array_map( 'floatval', $vector ) : null;
	}

	/**
	 * Convierte el formato genérico [{role, content}] al formato de Gemini,
	 * separando el mensaje 'system' como systemInstruction.
	 */
	private function to_gemini_format( array $messages ): array {
		$system_instruction = null;
		$contents            = [];

		foreach ( $messages as $message ) {
			$role = $message['role'] ?? 'user';
			$text = (string) ( $message['content'] ?? '' );

			if ( 'system' === $role ) {
				$system_instruction = ( $system_instruction ? $system_instruction . "\n\n" : '' ) . $text;
				continue;
			}

			$contents[] = [
				'role'  => 'assistant' === $role ? 'model' : 'user',
				'parts' => [ [ 'text' => $text ] ],
			];
		}

		return [ $system_instruction, $contents ];
	}

	/**
	 * @param array|WP_Error $response
	 */
	private function parse_response( $response ): array {
		if ( is_wp_error( $response ) ) {
			throw new RuntimeException( esc_html( $response->get_error_message() ) );
		}

		$code = wp_remote_retrieve_response_code( $response );
		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( $code < 200 || $code >= 300 ) {
			$message = $body['error']['message'] ?? "HTTP {$code}";
			throw new RuntimeException( esc_html( "Gemini: {$message}" ) );
		}

		return is_array( $body ) ? $body : [];
	}
}
