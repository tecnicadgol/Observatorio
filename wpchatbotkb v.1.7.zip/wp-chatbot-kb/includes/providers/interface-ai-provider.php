<?php

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Contrato que debe cumplir cualquier proveedor de IA (OpenAI, Gemini, u otros
 * añadidos vía el filtro 'wpckb_ai_providers').
 */
interface WPCKB_AI_Provider {

	/**
	 * Genera una respuesta de chat.
	 *
	 * @param array $messages Lista de mensajes: [['role' => 'system'|'user'|'assistant', 'content' => string], ...]
	 * @param array $options  Opciones adicionales: temperature, max_tokens, etc.
	 *
	 * @throws RuntimeException Si la llamada a la API falla.
	 */
	public function chat( array $messages, array $options = [] ): string;

	/**
	 * Genera el vector de embedding de un texto. Devuelve null si el proveedor
	 * no soporta embeddings o la llamada falla (se debe hacer fallback a búsqueda por palabras clave).
	 *
	 * @return float[]|null
	 */
	public function embed( string $text ): ?array;

	public function get_slug(): string;

	public function get_label(): string;
}
