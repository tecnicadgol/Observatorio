<?php

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Proveedor OpenAI (Chat Completions + Embeddings).
 */
final class WPCKB_OpenAI_Provider implements WPCKB_AI_Provider {

	private const CHAT_ENDPOINT      = 'https://api.openai.com/v1/chat/completions';
	private const EMBEDDING_ENDPOINT = 'https://api.openai.com/v1/embeddings';

	public function __construct(
		private readonly string $api_key,
		private readonly string $chat_model,
		private readonly string $embedding_model
	) {
	}

	public function get_slug(): string {
		return 'openai';
	}

	public function get_label(): string {
		return 'OpenAI';
	}

	public function chat( array $messages, array $options = [] ): string {
		if ( '' === $this->api_key ) {
			throw new RuntimeException( __( 'No se ha configurado la clave de API de OpenAI.', 'wp-chatbot-kb' ) );
		}

		$body = [
			'model'       => $this->chat_model,
			'messages'    => $messages,
			'temperature' => $options['temperature'] ?? 0.3,
			'max_tokens'  => $options['max_tokens'] ?? 600,
		];

		$response = wp_remote_post(
			self::CHAT_ENDPOINT,
			[
				'timeout' => 30,
				'headers' => [
					'Authorization' => 'Bearer ' . $this->api_key,
					'Content-Type'  => 'application/json',
				],
				'body'    => wp_json_encode( $body ),
			]
		);

		$data = $this->parse_response( $response );

		$content = $data['choices'][0]['message']['content'] ?? null;
		if ( ! is_string( $content ) || '' === trim( $content ) ) {
			throw new RuntimeException( __( 'OpenAI devolvió una respuesta vacía.', 'wp-chatbot-kb' ) );
		}

		return trim( $content );
	}

	public function embed( string $text ): ?array {
		if ( '' === $this->api_key || '' === trim( $text ) ) {
			return null;
		}

		$response = wp_remote_post(
			self::EMBEDDING_ENDPOINT,
			[
				'timeout' => 20,
				'headers' => [
					'Authorization' => 'Bearer ' . $this->api_key,
					'Content-Type'  => 'application/json',
				],
				'body'    => wp_json_encode(
					[
						'model' => $this->embedding_model,
						'input' => mb_substr( $text, 0, 8000 ),
					]
				),
			]
		);

		try {
			$data = $this->parse_response( $response );
		} catch ( RuntimeException ) {
			return null;
		}

		$vector = $data['data'][0]['embedding'] ?? null;
		return is_array( $vector ) ? array_map( 'floatval', $vector ) : null;
	}

	/**
	 * @param array|WP_Error $response
	 */
	private function parse_response( $response ): array {
		if ( is_wp_error( $response ) ) {
			throw new RuntimeException( esc_html( $response->get_error_message() ) );
		}

		$code = wp_remote_retrieve_response_code( $response );
		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( $code < 200 || $code >= 300 ) {
			$message = $body['error']['message'] ?? "HTTP {$code}";
			throw new RuntimeException( esc_html( "OpenAI: {$message}" ) );
		}

		return is_array( $body ) ? $body : [];
	}
}
