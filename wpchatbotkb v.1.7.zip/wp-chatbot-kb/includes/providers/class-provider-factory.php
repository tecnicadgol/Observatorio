<?php

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Crea instancias de proveedores de IA a partir de los ajustes guardados.
 * Otros plugins/temas pueden registrar proveedores adicionales (p. ej. un
 * modelo local) enganchándose al filtro 'wpckb_ai_providers'.
 */
final class WPCKB_Provider_Factory {

	/**
	 * @return array<string,callable(array):WPCKB_AI_Provider>
	 */
	private static function registry(): array {
		$providers = [
			'openai' => static fn ( array $settings ): WPCKB_AI_Provider => new WPCKB_OpenAI_Provider(
				(string) $settings['openai_api_key'],
				(string) $settings['openai_chat_model'],
				(string) $settings['openai_embedding_model']
			),
			'gemini' => static fn ( array $settings ): WPCKB_AI_Provider => new WPCKB_Gemini_Provider(
				(string) $settings['gemini_api_key'],
				(string) $settings['gemini_chat_model'],
				(string) $settings['gemini_embedding_model']
			),
			'anthropic' => static fn ( array $settings ): WPCKB_AI_Provider => new WPCKB_Anthropic_Provider(
				(string) $settings['anthropic_api_key'],
				(string) $settings['anthropic_chat_model']
			),
		];

		/**
		 * Filtro para registrar proveedores de IA adicionales.
		 *
		 * add_filter('wpckb_ai_providers', function(array $providers): array {
		 *     $providers['mi_proveedor'] = fn(array $settings) => new Mi_Provider(...);
		 *     return $providers;
		 * });
		 */
		return apply_filters( 'wpckb_ai_providers', $providers );
	}

	public static function create( array $settings ): WPCKB_AI_Provider {
		$slug     = (string) ( $settings['provider'] ?? 'openai' );
		$registry = self::registry();

		if ( ! isset( $registry[ $slug ] ) ) {
			throw new RuntimeException( esc_html( "Proveedor de IA desconocido: {$slug}" ) );
		}

		return $registry[ $slug ]( $settings );
	}

	/**
	 * @return array<string,string> slug => etiqueta legible, para poblar el <select> de ajustes.
	 */
	public static function get_available_providers( array $settings ): array {
		$labels = [];
		foreach ( self::registry() as $slug => $factory ) {
			try {
				$labels[ $slug ] = $factory( $settings )->get_label();
			} catch ( Throwable ) {
				$labels[ $slug ] = ucfirst( $slug );
			}
		}
		return $labels;
	}
}
