<?php

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Proveedor Anthropic Claude (API de Mensajes).
 *
 * Anthropic no ofrece una API de embeddings propia, por lo que embed() siempre
 * devuelve null: el plugin detecta esto automáticamente y usa búsqueda por
 * palabras clave como respaldo para la recuperación de contexto (ver WPCKB_Retriever).
 */
final class WPCKB_Anthropic_Provider implements WPCKB_AI_Provider {

	private const CHAT_ENDPOINT     = 'https://api.anthropic.com/v1/messages';
	private const ANTHROPIC_VERSION = '2023-06-01';

	public function __construct(
		private readonly string $api_key,
		private readonly string $chat_model
	) {
	}

	public function get_slug(): string {
		return 'anthropic';
	}

	public function get_label(): string {
		return 'Anthropic (Claude)';
	}

	public function chat( array $messages, array $options = [] ): string {
		if ( '' === $this->api_key ) {
			throw new RuntimeException( __( 'No se ha configurado la clave de API de Anthropic.', 'wp-chatbot-kb' ) );
		}

		$formatted = $this->to_anthropic_format( $messages );

		$body = [
			'model'       => $this->chat_model,
			'max_tokens'  => $options['max_tokens'] ?? 700,
			'temperature' => $options['temperature'] ?? 0.3,
			'messages'    => $formatted['messages'],
		];

		if ( '' !== $formatted['system'] ) {
			$body['system'] = $formatted['system'];
		}

		$response = wp_remote_post(
			self::CHAT_ENDPOINT,
			[
				'timeout' => 30,
				'headers' => [
					'x-api-key'         => $this->api_key,
					'anthropic-version' => self::ANTHROPIC_VERSION,
					'content-type'      => 'application/json',
				],
				'body'    => wp_json_encode( $body ),
			]
		);

		$data = $this->parse_response( $response );

		$text = '';
		foreach ( (array) ( $data['content'] ?? [] ) as $block ) {
			if ( isset( $block['type'], $block['text'] ) && 'text' === $block['type'] ) {
				$text .= $block['text'];
			}
		}

		if ( '' === trim( $text ) ) {
			throw new RuntimeException( __( 'Anthropic devolvió una respuesta vacía.', 'wp-chatbot-kb' ) );
		}

		return trim( $text );
	}

	public function embed( string $text ): ?array {
		return null;
	}

	/**
	 * Convierte el formato genérico [{role, content}] al formato de Anthropic:
	 * los mensajes 'system' se extraen a un campo aparte, y los mensajes
	 * user/assistant deben alternar estrictamente empezando por 'user'
	 * (se fusionan roles consecutivos repetidos para cumplir esa regla).
	 *
	 * @return array{system:string,messages:array<int,array{role:string,content:string}>}
	 */
	private function to_anthropic_format( array $messages ): array {
		$system_parts = [];
		$converted    = [];

		foreach ( $messages as $message ) {
			$role = $message['role'] ?? 'user';
			$text = (string) ( $message['content'] ?? '' );

			if ( 'system' === $role ) {
				$system_parts[] = $text;
				continue;
			}

			$role = 'assistant' === $role ? 'assistant' : 'user';

			$last_index = count( $converted ) - 1;
			if ( $last_index >= 0 && $converted[ $last_index ]['role'] === $role ) {
				$converted[ $last_index ]['content'] .= "\n\n" . $text;
			} else {
				$converted[] = [
					'role'    => $role,
					'content' => $text,
				];
			}
		}

		if ( ! empty( $converted ) && 'user' !== $converted[0]['role'] ) {
			array_unshift( $converted, [ 'role' => 'user', 'content' => '(inicio de conversación)' ] );
		}

		return [
			'system'   => implode( "\n\n", $system_parts ),
			'messages' => $converted,
		];
	}

	/**
	 * @param array|WP_Error $response
	 */
	private function parse_response( $response ): array {
		if ( is_wp_error( $response ) ) {
			throw new RuntimeException( esc_html( $response->get_error_message() ) );
		}

		$code = wp_remote_retrieve_response_code( $response );
		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( $code < 200 || $code >= 300 ) {
			$message = $body['error']['message'] ?? "HTTP {$code}";
			throw new RuntimeException( esc_html( "Anthropic: {$message}" ) );
		}

		return is_array( $body ) ? $body : [];
	}
}
