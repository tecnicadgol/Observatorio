( function () {
	'use strict';

	if ( typeof window.WPCKB_CHAT === 'undefined' ) {
		return;
	}

	var config = window.WPCKB_CHAT;

	// Textos de interfaz por idioma (independientes del idioma del panel de WordPress),
	// para que el selector Castellano/Guaraní también cambie la propia UI del chat.
	var STRINGS = {
		es: {
			placeholder: 'Escribe o dicta tu pregunta…',
			send: 'Enviar',
			thinking: 'Pensando…',
			listening: 'Escuchando…',
			mic: 'Hablar',
			mute: 'Silenciar voz',
			unmute: 'Activar voz',
			sources: 'Fuentes'
		},
		gn: {
			placeholder: 'Ehai térã eñe\'ẽ nde porandu…',
			send: 'Mondo',
			thinking: 'Apensa…',
			listening: 'Ahendu…',
			mic: 'Eñe\'ẽ',
			mute: 'Emongyngy ñe\'ẽ',
			unmute: 'Emyandy ñe\'ẽ',
			sources: 'Ogua\'u'
		}
	};

	function t( lang, key ) {
		return ( STRINGS[ lang ] && STRINGS[ lang ][ key ] ) || STRINGS.es[ key ] || key;
	}

	function getSessionId() {
		try {
			var existing = window.sessionStorage.getItem( 'wpckb_session_id' );
			if ( existing ) {
				return existing;
			}
			var fresh = 'wpckb-' + Date.now().toString( 36 ) + '-' + Math.random().toString( 36 ).slice( 2 );
			window.sessionStorage.setItem( 'wpckb_session_id', fresh );
			return fresh;
		} catch ( e ) {
			return 'wpckb-' + Date.now().toString( 36 );
		}
	}

	function storageGet( key, fallback ) {
		try {
			var v = window.sessionStorage.getItem( key );
			return null === v ? fallback : v;
		} catch ( e ) {
			return fallback;
		}
	}

	function storageSet( key, value ) {
		try {
			window.sessionStorage.setItem( key, value );
		} catch ( e ) {
			/* noop */
		}
	}

	// ---------------------------------------------------------------------
	// Voz: reconocimiento (STT) y síntesis (TTS) sobre la Web Speech API.
	// El soporte de guaraní no está garantizado en los navegadores; se intenta
	// igualmente y se degrada con gracia (mensaje de aviso, sin bloquear el chat).
	// ---------------------------------------------------------------------

	var SpeechRecognitionImpl = window.SpeechRecognition || window.webkitSpeechRecognition || null;
	var cachedVoices = [];

	function refreshVoices() {
		if ( 'speechSynthesis' in window ) {
			cachedVoices = window.speechSynthesis.getVoices();
		}
	}

	if ( 'speechSynthesis' in window ) {
		refreshVoices();
		window.speechSynthesis.onvoiceschanged = refreshVoices;
	}

	// Pistas de nombre para preferir, entre las voces del sistema del visitante,
	// una que suene femenina y con acento neutro (público objetivo joven).
	// No hay forma confiable de saber el "género" real de una voz vía la Web
	// Speech API: esto es una heurística por nombre, best-effort.
	var FEMALE_NAME_HINTS = [
		'female', 'mujer', 'femenin', 'mónica', 'monica', 'paulina', 'helena', 'sabina',
		'elvira', 'laura', 'lucía', 'lucia', 'marisol', 'camila', 'valentina', 'sofía',
		'sofia', 'isabela', 'carmen', 'pilar', 'zira', 'salli', 'joanna', 'nova', 'shimmer'
	];
	var MALE_NAME_HINTS = [
		'male', 'hombre', 'masculin', 'juan', 'jorge', 'pablo', 'raúl', 'raul', 'diego',
		'carlos', 'miguel', 'antonio', 'enrique', 'matthew', 'brian'
	];
	// Variantes de español que suelen sonar menos marcadas regionalmente.
	var NEUTRAL_LANG_HINTS = [ 'es-419', 'es-us' ];

	function scoreVoice( voice, langPrefix ) {
		var lang = ( voice.lang || '' ).toLowerCase();
		if ( lang.indexOf( langPrefix ) !== 0 ) {
			return null; // idioma no coincide.
		}

		var name = ( voice.name || '' ).toLowerCase();
		var score = 0;

		NEUTRAL_LANG_HINTS.forEach( function ( hint ) {
			if ( 0 === lang.indexOf( hint ) ) {
				score += 3;
			}
		} );

		if ( FEMALE_NAME_HINTS.some( function ( hint ) { return name.indexOf( hint ) !== -1; } ) ) {
			score += 5;
		}
		if ( MALE_NAME_HINTS.some( function ( hint ) { return name.indexOf( hint ) !== -1; } ) ) {
			score -= 5;
		}
		if ( ! voice.localService ) {
			score += 1; // las voces de red (p.ej. Google) suelen sonar menos robóticas.
		}

		return score;
	}

	function pickVoice( langPrefix, nameHint ) {
		if ( nameHint ) {
			var trimmedHint = nameHint.trim().toLowerCase();
			var hinted = cachedVoices.find( function ( v ) {
				return v.name && v.name.toLowerCase().indexOf( trimmedHint ) !== -1;
			} );
			if ( hinted ) {
				return hinted;
			}
		}

		var best = null;
		var bestScore = null;

		cachedVoices.forEach( function ( v ) {
			var s = scoreVoice( v, langPrefix );
			if ( null !== s && ( null === bestScore || s > bestScore ) ) {
				bestScore = s;
				best = v;
			}
		} );

		return best;
	}

	function speak( text, lang, onEnd ) {
		if ( ! ( 'speechSynthesis' in window ) || ! text ) {
			if ( onEnd ) {
				onEnd();
			}
			return;
		}

		window.speechSynthesis.cancel();

		var utter = new window.SpeechSynthesisUtterance( text );
		var bcp47 = 'gn' === lang ? 'gn' : 'es-ES';
		utter.lang = bcp47;

		var voice = pickVoice( 'gn' === lang ? 'gn' : 'es', config.voiceNameHint );
		if ( voice ) {
			utter.voice = voice;
			utter.lang = voice.lang;
		}

		if ( onEnd ) {
			utter.onend = onEnd;
			utter.onerror = onEnd;
		}

		window.speechSynthesis.speak( utter );
	}

	function buildWidget( root ) {
		root.style.setProperty( '--wpckb-color', config.color || '#2563eb' );

		var currentLang = storageGet( 'wpckb_lang', config.defaultLanguage || 'es' );
		var muted = 'gn' === currentLang; // por defecto, evita reproducir voz en un idioma sin soporte fiable hasta que el usuario decida.
		muted = '1' === storageGet( 'wpckb_muted', muted ? '1' : '0' );

		// -- Botón flotante (icono animado) -------------------------------
		var toggle = document.createElement( 'button' );
		toggle.className = 'wpckb-toggle';
		toggle.type = 'button';
		toggle.setAttribute( 'aria-label', config.title || 'Chat' );
		toggle.appendChild( createMascotEl( 'wpckb-toggle-avatar', 'icon' ) );

		// -- Panel ----------------------------------------------------------
		var panel = document.createElement( 'div' );
		panel.className = 'wpckb-panel';

		var header = document.createElement( 'div' );
		header.className = 'wpckb-header';

		var headerLeft = document.createElement( 'div' );
		headerLeft.className = 'wpckb-header-left';
		var miniAvatar = createMascotEl( 'wpckb-header-avatar', 'icon' );
		var headerTitle = document.createElement( 'span' );
		headerTitle.textContent = config.title || 'Asistente';
		headerLeft.appendChild( miniAvatar );
		headerLeft.appendChild( headerTitle );

		var headerRight = document.createElement( 'div' );
		headerRight.className = 'wpckb-header-right';

		var langToggle = null;
		if ( config.enableGuarani ) {
			langToggle = document.createElement( 'div' );
			langToggle.className = 'wpckb-lang-toggle';
			[ 'es', 'gn' ].forEach( function ( code ) {
				var btn = document.createElement( 'button' );
				btn.type = 'button';
				btn.textContent = code.toUpperCase();
				btn.dataset.lang = code;
				btn.className = code === currentLang ? 'wpckb-lang-active' : '';
				langToggle.appendChild( btn );
			} );
			headerRight.appendChild( langToggle );
		}

		var muteBtn = null;
		if ( config.enableVoiceOutput ) {
			muteBtn = document.createElement( 'button' );
			muteBtn.type = 'button';
			muteBtn.className = 'wpckb-mute-btn';
			muteBtn.innerHTML = muted ? '🔇' : '🔊';
			muteBtn.title = muted ? t( currentLang, 'unmute' ) : t( currentLang, 'mute' );
			headerRight.appendChild( muteBtn );
		}

		var closeBtn = document.createElement( 'button' );
		closeBtn.type = 'button';
		closeBtn.className = 'wpckb-close-btn';
		closeBtn.innerHTML = '&times;';
		closeBtn.setAttribute( 'aria-label', 'Cerrar' );
		headerRight.appendChild( closeBtn );

		header.appendChild( headerLeft );
		header.appendChild( headerRight );

		var messages = document.createElement( 'div' );
		messages.className = 'wpckb-messages';

		// -- Escenario de saludo (mascota completa + globo de texto) -------
		var greetOverlay = document.createElement( 'div' );
		greetOverlay.className = 'wpckb-greet-overlay';
		var greetMascot = createMascotEl( 'wpckb-greet-avatar', 'full' );
		var greetBubble = document.createElement( 'div' );
		greetBubble.className = 'wpckb-greet-bubble';
		greetOverlay.appendChild( greetMascot );
		greetOverlay.appendChild( greetBubble );

		var inputRow = document.createElement( 'div' );
		inputRow.className = 'wpckb-input-row';

		var micBtn = null;
		if ( config.enableVoiceInput && SpeechRecognitionImpl ) {
			micBtn = document.createElement( 'button' );
			micBtn.type = 'button';
			micBtn.className = 'wpckb-mic-btn';
			micBtn.innerHTML = '🎤';
			micBtn.title = t( currentLang, 'mic' );
			inputRow.appendChild( micBtn );
		}

		var textarea = document.createElement( 'textarea' );
		textarea.rows = 1;
		textarea.placeholder = t( currentLang, 'placeholder' );

		var sendBtn = document.createElement( 'button' );
		sendBtn.type = 'button';
		sendBtn.textContent = t( currentLang, 'send' );

		inputRow.appendChild( textarea );
		inputRow.appendChild( sendBtn );

		panel.appendChild( header );
		panel.appendChild( greetOverlay );
		panel.appendChild( messages );
		panel.appendChild( inputRow );

		root.appendChild( panel );
		root.appendChild( toggle );

		var sessionId = getSessionId();
		var busy = false;
		var hasGreeted = '1' === storageGet( 'wpckb_greeted', '0' );

		function currentWelcome() {
			var w = config.welcome || {};
			return w[ currentLang ] || w.es || '';
		}

		function applyLanguageToUI() {
			textarea.placeholder = t( currentLang, 'placeholder' );
			sendBtn.textContent = t( currentLang, 'send' );
			if ( micBtn ) {
				micBtn.title = t( currentLang, 'mic' );
			}
			if ( muteBtn ) {
				muteBtn.title = muted ? t( currentLang, 'unmute' ) : t( currentLang, 'mute' );
			}
			if ( langToggle ) {
				Array.prototype.forEach.call( langToggle.children, function ( btn ) {
					btn.className = btn.dataset.lang === currentLang ? 'wpckb-lang-active' : '';
				} );
			}
		}

		function addMessage( role, text, sources ) {
			var el = document.createElement( 'div' );
			el.className = 'wpckb-msg wpckb-msg-' + role;
			el.textContent = text;

			if ( sources && sources.length ) {
				var wrap = document.createElement( 'div' );
				wrap.className = 'wpckb-sources';

				var label = document.createElement( 'span' );
				label.className = 'wpckb-sources-label';
				label.textContent = t( currentLang, 'sources' ) + ':';
				wrap.appendChild( label );

				sources.forEach( function ( source ) {
					var url = typeof source === 'string' ? source : source.url;
					var title = ( typeof source === 'object' && source.title ) ? source.title : url;
					if ( ! url ) {
						return;
					}
					var link = document.createElement( 'a' );
					link.href = url;
					link.target = '_blank';
					link.rel = 'noopener noreferrer';
					link.textContent = title;
					wrap.appendChild( link );
				} );

				el.appendChild( wrap );
			}

			messages.appendChild( el );
			messages.scrollTop = messages.scrollHeight;
		}

		function playGreeting() {
			var text = currentWelcome();
			greetBubble.textContent = text;
			greetOverlay.classList.add( 'wpckb-greet-open' );
			greetMascot.classList.add( 'wpckb-wave-anim' );

			addMessage( 'assistant', text );
			storageSet( 'wpckb_greeted', '1' );
			hasGreeted = true;

			var dismiss = function () {
				greetOverlay.classList.remove( 'wpckb-greet-open' );
				greetMascot.classList.remove( 'wpckb-wave-anim' );
				if ( 'speechSynthesis' in window ) {
					window.speechSynthesis.cancel();
				}
			};

			if ( config.enableVoiceOutput && ! muted ) {
				speak( text, currentLang, function () {
					window.setTimeout( dismiss, 600 );
				} );
				window.setTimeout( dismiss, 7000 ); // límite de seguridad.
			} else {
				window.setTimeout( dismiss, 3200 );
			}

			greetOverlay.addEventListener( 'click', dismiss, { once: true } );
		}

		function sendMessage( text ) {
			text = ( text || textarea.value ).trim();
			if ( ! text || busy ) {
				return;
			}

			busy = true;
			sendBtn.disabled = true;
			addMessage( 'user', text );
			textarea.value = '';

			var thinking = document.createElement( 'div' );
			thinking.className = 'wpckb-msg wpckb-msg-assistant';
			thinking.textContent = t( currentLang, 'thinking' );
			messages.appendChild( thinking );
			messages.scrollTop = messages.scrollHeight;

			fetch( config.restUrl, {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json',
					'X-WP-Nonce': config.nonce
				},
				body: JSON.stringify( { message: text, session_id: sessionId, lang: currentLang } )
			} )
				.then( function ( response ) {
					return response.json().then( function ( data ) {
						return { ok: response.ok, data: data };
					} );
				} )
				.then( function ( result ) {
					thinking.remove();
					if ( result.ok && result.data && result.data.answer ) {
						addMessage( 'assistant', result.data.answer, result.data.sources );
						if ( config.enableVoiceOutput && ! muted ) {
							speak( result.data.answer, currentLang );
						}
					} else {
						var message = ( result.data && result.data.message ) ? result.data.message : 'Ha ocurrido un error.';
						addMessage( 'error', message );
					}
				} )
				.catch( function () {
					thinking.remove();
					addMessage( 'error', 'Ha ocurrido un error. Inténtalo de nuevo.' );
				} )
				.finally( function () {
					busy = false;
					sendBtn.disabled = false;
				} );
		}

		// -- Reconocimiento de voz (dictado) --------------------------------
		var recognition = null;
		var listening = false;

		function stopListening() {
			listening = false;
			if ( micBtn ) {
				micBtn.classList.remove( 'is-listening' );
			}
		}

		function startListening() {
			if ( ! SpeechRecognitionImpl ) {
				return;
			}

			recognition = new SpeechRecognitionImpl();
			recognition.lang = 'gn' === currentLang ? 'gn' : 'es-ES';
			recognition.interimResults = true;
			recognition.continuous = false;

			recognition.onstart = function () {
				listening = true;
				micBtn.classList.add( 'is-listening' );
				textarea.placeholder = t( currentLang, 'listening' );
			};

			recognition.onresult = function ( event ) {
				var transcript = '';
				var isFinal = false;
				for ( var i = event.resultIndex; i < event.results.length; i++ ) {
					transcript += event.results[ i ][ 0 ].transcript;
					if ( event.results[ i ].isFinal ) {
						isFinal = true;
					}
				}
				textarea.value = transcript;
				if ( isFinal ) {
					stopListening();
					sendMessage( transcript );
				}
			};

			recognition.onerror = function () {
				stopListening();
				textarea.placeholder = t( currentLang, 'placeholder' );
			};

			recognition.onend = function () {
				stopListening();
				textarea.placeholder = t( currentLang, 'placeholder' );
			};

			recognition.start();
		}

		if ( micBtn ) {
			micBtn.addEventListener( 'click', function () {
				if ( listening && recognition ) {
					recognition.stop();
					return;
				}
				startListening();
			} );
		}

		if ( muteBtn ) {
			muteBtn.addEventListener( 'click', function () {
				muted = ! muted;
				storageSet( 'wpckb_muted', muted ? '1' : '0' );
				muteBtn.innerHTML = muted ? '🔇' : '🔊';
				muteBtn.title = muted ? t( currentLang, 'unmute' ) : t( currentLang, 'mute' );
				if ( muted && 'speechSynthesis' in window ) {
					window.speechSynthesis.cancel();
				}
			} );
		}

		if ( langToggle ) {
			langToggle.addEventListener( 'click', function ( event ) {
				var btn = event.target.closest( 'button' );
				if ( ! btn || ! btn.dataset.lang || btn.dataset.lang === currentLang ) {
					return;
				}
				currentLang = btn.dataset.lang;
				storageSet( 'wpckb_lang', currentLang );
				applyLanguageToUI();
			} );
		}

		toggle.addEventListener( 'click', function () {
			var opening = ! panel.classList.contains( 'wpckb-open' );
			panel.classList.toggle( 'wpckb-open' );

			if ( opening ) {
				textarea.focus();
				if ( config.greetOnOpen && ! hasGreeted ) {
					playGreeting();
				}
			}
		} );

		closeBtn.addEventListener( 'click', function () {
			panel.classList.remove( 'wpckb-open' );
			if ( 'speechSynthesis' in window ) {
				window.speechSynthesis.cancel();
			}
		} );

		sendBtn.addEventListener( 'click', function () {
			sendMessage();
		} );

		textarea.addEventListener( 'keydown', function ( event ) {
			if ( 'Enter' === event.key && ! event.shiftKey ) {
				event.preventDefault();
				sendMessage();
			}
		} );

		applyLanguageToUI();

		if ( ! config.greetOnOpen && currentWelcome() ) {
			addMessage( 'assistant', currentWelcome() );
		}
	}

	function createMascotEl( className, variant ) {
		var el;
		var useFull = 'full' === variant || 'video' === config.mascotType;
		var src = useFull ? config.mascotUrl : ( config.mascotIconUrl || config.mascotUrl );

		if ( 'video' === config.mascotType ) {
			el = document.createElement( 'video' );
			el.src = src;
			el.muted = true;
			el.loop = true;
			el.autoplay = true;
			el.playsInline = true;
		} else {
			el = document.createElement( 'img' );
			el.src = src;
			el.alt = config.title || 'Asistente';
		}
		el.className = className;
		return el;
	}

	document.addEventListener( 'DOMContentLoaded', function () {
		var root = document.getElementById( 'wpckb-chat-root' );
		if ( root ) {
			buildWidget( root );
		}

		var inline = document.querySelectorAll( '.wpckb-chat-inline' );
		inline.forEach( function ( node ) {
			node.classList.add( 'wpckb-position-bottom-right' );
			node.style.position = 'relative';
			buildWidget( node );
			var panel = node.querySelector( '.wpckb-panel' );
			var toggleBtn = node.querySelector( '.wpckb-toggle' );
			if ( panel && toggleBtn ) {
				panel.classList.add( 'wpckb-open' );
				toggleBtn.style.display = 'none';
				panel.style.position = 'static';
				panel.style.width = '100%';
				panel.style.height = '520px';
			}
		} );
	} );
} )();
