<?php
/**
 * Vista: historial de conversaciones. Variable disponible: $logs.
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** @var array $logs */
?>
<div class="wrap wpckb-wrap">
	<h1><?php esc_html_e( 'Conversaciones recientes', 'wp-chatbot-kb' ); ?></h1>
	<p class="description"><?php esc_html_e( 'Últimos 200 mensajes registrados (según la configuración de retención en Ajustes).', 'wp-chatbot-kb' ); ?></p>

	<table class="widefat striped">
		<thead>
			<tr>
				<th style="width:160px;"><?php esc_html_e( 'Fecha', 'wp-chatbot-kb' ); ?></th>
				<th style="width:220px;"><?php esc_html_e( 'Sesión', 'wp-chatbot-kb' ); ?></th>
				<th style="width:100px;"><?php esc_html_e( 'Rol', 'wp-chatbot-kb' ); ?></th>
				<th><?php esc_html_e( 'Mensaje', 'wp-chatbot-kb' ); ?></th>
			</tr>
		</thead>
		<tbody>
			<?php if ( empty( $logs ) ) : ?>
				<tr><td colspan="4"><?php esc_html_e( 'Todavía no hay conversaciones registradas.', 'wp-chatbot-kb' ); ?></td></tr>
			<?php endif; ?>
			<?php foreach ( $logs as $log ) : ?>
				<tr>
					<td><?php echo esc_html( $log['created_at'] ); ?></td>
					<td><code><?php echo esc_html( $log['session_id'] ); ?></code></td>
					<td><?php echo esc_html( 'assistant' === $log['role'] ? __( 'Asistente', 'wp-chatbot-kb' ) : __( 'Usuario', 'wp-chatbot-kb' ) ); ?></td>
					<td><?php echo esc_html( $log['message'] ); ?></td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
</div>
