<?php
/**
 * Vista: página de base de conocimiento. Variable disponible: $sources.
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** @var array $sources */

$status_labels = [
	'pending' => __( 'Pendiente', 'wp-chatbot-kb' ),
	'ready'   => __( 'Listo', 'wp-chatbot-kb' ),
	'error'   => __( 'Error', 'wp-chatbot-kb' ),
];
?>
<div class="wrap wpckb-wrap">
	<h1><?php esc_html_e( 'Base de conocimiento', 'wp-chatbot-kb' ); ?></h1>
	<p class="description">
		<?php esc_html_e( 'Añade enlaces públicos (documentación, FAQs, políticas, páginas de producto…) o pega contenido manualmente. El asistente solo responderá usando este material.', 'wp-chatbot-kb' ); ?>
	</p>

	<div class="wpckb-columns">
		<div class="wpckb-column">
			<h2><?php esc_html_e( 'Añadir enlace público', 'wp-chatbot-kb' ); ?></h2>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<?php wp_nonce_field( 'wpckb_kb_action' ); ?>
				<input type="hidden" name="action" value="wpckb_add_url_source" />
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="source_url"><?php esc_html_e( 'URL', 'wp-chatbot-kb' ); ?></label></th>
						<td>
							<input type="url" required id="source_url" name="source_url" class="regular-text" placeholder="https://ejemplo.com/pagina-o-documento.pdf" />
							<p class="description"><?php esc_html_e( 'Admite páginas HTML y también archivos PDF (por ejemplo, el texto de una ley). El asistente citará este enlace cuando responda con información de este documento.', 'wp-chatbot-kb' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="title_url"><?php esc_html_e( 'Título (opcional)', 'wp-chatbot-kb' ); ?></label></th>
						<td><input type="text" id="title_url" name="title" class="regular-text" /></td>
					</tr>
				</table>
				<?php submit_button( __( 'Descargar y añadir', 'wp-chatbot-kb' ), 'primary', 'submit', false ); ?>
			</form>
		</div>

		<div class="wpckb-column">
			<h2><?php esc_html_e( 'Carga masiva de URLs', 'wp-chatbot-kb' ); ?></h2>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<?php wp_nonce_field( 'wpckb_kb_action' ); ?>
				<input type="hidden" name="action" value="wpckb_add_bulk_urls" />
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="bulk_urls"><?php esc_html_e( 'Una URL por línea', 'wp-chatbot-kb' ); ?></label></th>
						<td>
							<textarea required id="bulk_urls" name="bulk_urls" rows="6" class="large-text" placeholder="https://www.bacn.gov.py/leyes-paraguayas/13202/ley-n-7698-2026...&#10;Ley de Hambre Cero | https://www.bacn.gov.py/leyes-paraguayas/..."></textarea>
							<p class="description"><?php esc_html_e( 'Pegá varios links copiados de un listado (por ejemplo, "Leyes por año"). Opcional: "Título | URL" para fijar el título vos mismo. Se procesan hasta 30 por tanda; las que ya estén cargadas se omiten automáticamente.', 'wp-chatbot-kb' ); ?></p>
						</td>
					</tr>
				</table>
				<?php submit_button( __( 'Procesar lista', 'wp-chatbot-kb' ), 'primary', 'submit', false ); ?>
			</form>
		</div>

		<div class="wpckb-column">
			<h2><?php esc_html_e( 'Añadir contenido manual', 'wp-chatbot-kb' ); ?></h2>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<?php wp_nonce_field( 'wpckb_kb_action' ); ?>
				<input type="hidden" name="action" value="wpckb_add_manual_source" />
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="title_manual"><?php esc_html_e( 'Título', 'wp-chatbot-kb' ); ?></label></th>
						<td><input type="text" id="title_manual" name="title" class="regular-text" placeholder="<?php esc_attr_e( 'Preguntas frecuentes de envío', 'wp-chatbot-kb' ); ?>" /></td>
					</tr>
					<tr>
						<th scope="row"><label for="content_manual"><?php esc_html_e( 'Contenido', 'wp-chatbot-kb' ); ?></label></th>
						<td><textarea required id="content_manual" name="content" rows="6" class="large-text"></textarea></td>
					</tr>
				</table>
				<?php submit_button( __( 'Añadir a la base de conocimiento', 'wp-chatbot-kb' ), 'primary', 'submit', false ); ?>
			</form>
		</div>
	</div>

	<h2><?php esc_html_e( 'Fuentes registradas', 'wp-chatbot-kb' ); ?></h2>
	<table class="widefat striped">
		<thead>
			<tr>
				<th><?php esc_html_e( 'Título', 'wp-chatbot-kb' ); ?></th>
				<th><?php esc_html_e( 'Tipo', 'wp-chatbot-kb' ); ?></th>
				<th><?php esc_html_e( 'Estado', 'wp-chatbot-kb' ); ?></th>
				<th><?php esc_html_e( 'Fragmentos', 'wp-chatbot-kb' ); ?></th>
				<th><?php esc_html_e( 'Última actualización', 'wp-chatbot-kb' ); ?></th>
				<th><?php esc_html_e( 'Acciones', 'wp-chatbot-kb' ); ?></th>
			</tr>
		</thead>
		<tbody>
			<?php if ( empty( $sources ) ) : ?>
				<tr><td colspan="6"><?php esc_html_e( 'Todavía no has añadido ninguna fuente.', 'wp-chatbot-kb' ); ?></td></tr>
			<?php endif; ?>
			<?php foreach ( $sources as $source ) : ?>
				<tr>
					<td>
						<strong><?php echo esc_html( $source['title'] ?: __( '(sin título)', 'wp-chatbot-kb' ) ); ?></strong>
						<?php if ( ! empty( $source['source_url'] ) ) : ?>
							<br /><a href="<?php echo esc_url( $source['source_url'] ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( $source['source_url'] ); ?></a>
						<?php endif; ?>
						<?php if ( 'error' === $source['status'] && ! empty( $source['error_message'] ) ) : ?>
							<br /><span class="wpckb-error-text"><?php echo esc_html( $source['error_message'] ); ?></span>
						<?php endif; ?>
					</td>
					<td><?php echo esc_html( 'url' === $source['type'] ? __( 'Enlace', 'wp-chatbot-kb' ) : __( 'Manual', 'wp-chatbot-kb' ) ); ?></td>
					<td><span class="wpckb-status wpckb-status-<?php echo esc_attr( $source['status'] ); ?>"><?php echo esc_html( $status_labels[ $source['status'] ] ?? $source['status'] ); ?></span></td>
					<td><?php echo esc_html( (string) $source['chunk_count'] ); ?></td>
					<td><?php echo esc_html( $source['last_fetched_at'] ?: '—' ); ?></td>
					<td>
						<?php if ( 'url' === $source['type'] ) : ?>
							<a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=wpckb_reingest_source&id=' . $source['id'] ), 'wpckb_kb_action' ) ); ?>">
								<?php esc_html_e( 'Reprocesar', 'wp-chatbot-kb' ); ?>
							</a> |
						<?php endif; ?>
						<a class="wpckb-delete-link" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=wpckb_delete_source&id=' . $source['id'] ), 'wpckb_kb_action' ) ); ?>">
							<?php esc_html_e( 'Eliminar', 'wp-chatbot-kb' ); ?>
						</a>
					</td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
</div>
