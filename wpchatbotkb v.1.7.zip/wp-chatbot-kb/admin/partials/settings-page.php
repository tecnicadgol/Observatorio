<?php
/**
 * Vista: página de ajustes. Variables disponibles: $settings, $providers.
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** @var array $settings */
/** @var array $providers */
/** @var string $mascot_url */
/** @var string $mascot_mime */
/** @var bool $mascot_is_default */

$roles = wp_roles()->get_names();
?>
<div class="wrap wpckb-wrap">
	<h1><?php esc_html_e( 'WP Chatbot KB — Ajustes', 'wp-chatbot-kb' ); ?></h1>
	<p class="description">
		<?php esc_html_e( 'Configura el proveedor de IA, el comportamiento del asistente y la apariencia del widget de chat.', 'wp-chatbot-kb' ); ?>
	</p>

	<form method="post" action="options.php">
		<?php settings_fields( 'wpckb_settings_group' ); ?>

		<h2 class="title"><?php esc_html_e( 'Proveedor de IA', 'wp-chatbot-kb' ); ?></h2>
		<table class="form-table" role="presentation">
			<tr>
				<th scope="row"><label for="wpckb_provider"><?php esc_html_e( 'Proveedor activo', 'wp-chatbot-kb' ); ?></label></th>
				<td>
					<select name="wpckb_settings[provider]" id="wpckb_provider">
						<?php foreach ( $providers as $slug => $label ) : ?>
							<option value="<?php echo esc_attr( $slug ); ?>" <?php selected( $settings['provider'], $slug ); ?>>
								<?php echo esc_html( $label ); ?>
							</option>
						<?php endforeach; ?>
					</select>
					<p class="description"><?php esc_html_e( 'Puedes cambiar de proveedor en cualquier momento sin perder la base de conocimiento.', 'wp-chatbot-kb' ); ?></p>
				</td>
			</tr>
		</table>

		<h3><?php esc_html_e( 'OpenAI', 'wp-chatbot-kb' ); ?></h3>
		<table class="form-table" role="presentation">
			<tr>
				<th scope="row"><label for="wpckb_openai_key"><?php esc_html_e( 'Clave de API', 'wp-chatbot-kb' ); ?></label></th>
				<td>
					<input type="password" id="wpckb_openai_key" name="wpckb_settings[openai_api_key]" class="regular-text" autocomplete="off" placeholder="<?php echo $settings['openai_api_key'] ? esc_attr__( '•••••••••••••• (guardada)', 'wp-chatbot-kb' ) : 'sk-...'; ?>" />
					<label style="margin-left:8px;">
						<input type="checkbox" name="wpckb_settings[clear_openai_api_key]" value="1" /> <?php esc_html_e( 'Borrar clave guardada', 'wp-chatbot-kb' ); ?>
					</label>
					<p class="description"><?php esc_html_e( 'Se almacena cifrada. Déjala en blanco para conservar la clave actual.', 'wp-chatbot-kb' ); ?></p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="wpckb_openai_chat_model"><?php esc_html_e( 'Modelo de chat', 'wp-chatbot-kb' ); ?></label></th>
				<td><input type="text" id="wpckb_openai_chat_model" name="wpckb_settings[openai_chat_model]" class="regular-text" value="<?php echo esc_attr( $settings['openai_chat_model'] ); ?>" placeholder="gpt-4o-mini" /></td>
			</tr>
			<tr>
				<th scope="row"><label for="wpckb_openai_embedding_model"><?php esc_html_e( 'Modelo de embeddings', 'wp-chatbot-kb' ); ?></label></th>
				<td><input type="text" id="wpckb_openai_embedding_model" name="wpckb_settings[openai_embedding_model]" class="regular-text" value="<?php echo esc_attr( $settings['openai_embedding_model'] ); ?>" placeholder="text-embedding-3-small" /></td>
			</tr>
		</table>

		<h3><?php esc_html_e( 'Google Gemini', 'wp-chatbot-kb' ); ?></h3>
		<table class="form-table" role="presentation">
			<tr>
				<th scope="row"><label for="wpckb_gemini_key"><?php esc_html_e( 'Clave de API', 'wp-chatbot-kb' ); ?></label></th>
				<td>
					<input type="password" id="wpckb_gemini_key" name="wpckb_settings[gemini_api_key]" class="regular-text" autocomplete="off" placeholder="<?php echo $settings['gemini_api_key'] ? esc_attr__( '•••••••••••••• (guardada)', 'wp-chatbot-kb' ) : 'AIza...'; ?>" />
					<label style="margin-left:8px;">
						<input type="checkbox" name="wpckb_settings[clear_gemini_api_key]" value="1" /> <?php esc_html_e( 'Borrar clave guardada', 'wp-chatbot-kb' ); ?>
					</label>
					<p class="description"><?php esc_html_e( 'Se almacena cifrada. Déjala en blanco para conservar la clave actual.', 'wp-chatbot-kb' ); ?></p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="wpckb_gemini_chat_model"><?php esc_html_e( 'Modelo de chat', 'wp-chatbot-kb' ); ?></label></th>
				<td>
					<input type="text" id="wpckb_gemini_chat_model" name="wpckb_settings[gemini_chat_model]" class="regular-text" value="<?php echo esc_attr( $settings['gemini_chat_model'] ); ?>" placeholder="gemini-2.0-flash" />
					<p class="description"><?php esc_html_e( 'Escribe el identificador exacto del modelo (por ejemplo, la versión de Gemini que tengas disponible en tu cuenta de Google AI).', 'wp-chatbot-kb' ); ?></p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="wpckb_gemini_embedding_model"><?php esc_html_e( 'Modelo de embeddings', 'wp-chatbot-kb' ); ?></label></th>
				<td><input type="text" id="wpckb_gemini_embedding_model" name="wpckb_settings[gemini_embedding_model]" class="regular-text" value="<?php echo esc_attr( $settings['gemini_embedding_model'] ); ?>" placeholder="text-embedding-004" /></td>
			</tr>
		</table>

		<h3><?php esc_html_e( 'Anthropic (Claude)', 'wp-chatbot-kb' ); ?></h3>
		<table class="form-table" role="presentation">
			<tr>
				<th scope="row"><label for="wpckb_anthropic_key"><?php esc_html_e( 'Clave de API', 'wp-chatbot-kb' ); ?></label></th>
				<td>
					<input type="password" id="wpckb_anthropic_key" name="wpckb_settings[anthropic_api_key]" class="regular-text" autocomplete="off" placeholder="<?php echo $settings['anthropic_api_key'] ? esc_attr__( '•••••••••••••• (guardada)', 'wp-chatbot-kb' ) : 'sk-ant-...'; ?>" />
					<label style="margin-left:8px;">
						<input type="checkbox" name="wpckb_settings[clear_anthropic_api_key]" value="1" /> <?php esc_html_e( 'Borrar clave guardada', 'wp-chatbot-kb' ); ?>
					</label>
					<p class="description"><?php esc_html_e( 'Se almacena cifrada. Déjala en blanco para conservar la clave actual.', 'wp-chatbot-kb' ); ?></p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="wpckb_anthropic_chat_model"><?php esc_html_e( 'Modelo de chat', 'wp-chatbot-kb' ); ?></label></th>
				<td>
					<input type="text" id="wpckb_anthropic_chat_model" name="wpckb_settings[anthropic_chat_model]" class="regular-text" value="<?php echo esc_attr( $settings['anthropic_chat_model'] ); ?>" placeholder="claude-sonnet-5" />
					<p class="description"><?php esc_html_e( 'Anthropic no ofrece una API de embeddings propia: si elegís este proveedor como activo, la búsqueda en la base de conocimiento usa automáticamente palabras clave en vez de búsqueda semántica.', 'wp-chatbot-kb' ); ?></p>
				</td>
			</tr>
		</table>

		<h2 class="title"><?php esc_html_e( 'Comportamiento del asistente', 'wp-chatbot-kb' ); ?></h2>
		<table class="form-table" role="presentation">
			<tr>
				<th scope="row"><label for="wpckb_system_prompt"><?php esc_html_e( 'Instrucciones del sistema (prompt)', 'wp-chatbot-kb' ); ?></label></th>
				<td>
					<textarea id="wpckb_system_prompt" name="wpckb_settings[system_prompt]" rows="5" class="large-text"><?php echo esc_textarea( $settings['system_prompt'] ); ?></textarea>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="wpckb_top_k"><?php esc_html_e( 'Fragmentos de contexto a usar', 'wp-chatbot-kb' ); ?></label></th>
				<td><input type="number" min="1" max="10" id="wpckb_top_k" name="wpckb_settings[top_k]" value="<?php echo esc_attr( (string) $settings['top_k'] ); ?>" class="small-text" /></td>
			</tr>
			<tr>
				<th scope="row"><label for="wpckb_temperature"><?php esc_html_e( 'Temperatura', 'wp-chatbot-kb' ); ?></label></th>
				<td><input type="number" min="0" max="2" step="0.1" id="wpckb_temperature" name="wpckb_settings[temperature]" value="<?php echo esc_attr( (string) $settings['temperature'] ); ?>" class="small-text" /></td>
			</tr>
			<tr>
				<th scope="row"><label for="wpckb_max_history_turns"><?php esc_html_e( 'Turnos de historial a recordar', 'wp-chatbot-kb' ); ?></label></th>
				<td><input type="number" min="0" max="20" id="wpckb_max_history_turns" name="wpckb_settings[max_history_turns]" value="<?php echo esc_attr( (string) $settings['max_history_turns'] ); ?>" class="small-text" /></td>
			</tr>
			<tr>
				<th scope="row"><label for="wpckb_rate_limit"><?php esc_html_e( 'Límite de mensajes por minuto (por usuario)', 'wp-chatbot-kb' ); ?></label></th>
				<td><input type="number" min="1" max="120" id="wpckb_rate_limit" name="wpckb_settings[rate_limit_per_minute]" value="<?php echo esc_attr( (string) $settings['rate_limit_per_minute'] ); ?>" class="small-text" /></td>
			</tr>
			<tr>
				<th scope="row"><?php esc_html_e( 'Acceso restringido a roles', 'wp-chatbot-kb' ); ?></th>
				<td>
					<?php foreach ( $roles as $role_key => $role_label ) : ?>
						<label style="display:block;">
							<input type="checkbox" name="wpckb_settings[allowed_roles][]" value="<?php echo esc_attr( $role_key ); ?>" <?php checked( in_array( $role_key, $settings['allowed_roles'], true ) ); ?> />
							<?php echo esc_html( $role_label ); ?>
						</label>
					<?php endforeach; ?>
					<p class="description"><?php esc_html_e( 'Sin selección, el asistente es visible para todos los visitantes.', 'wp-chatbot-kb' ); ?></p>
				</td>
			</tr>
			<tr>
				<th scope="row"><?php esc_html_e( 'Registro de conversaciones', 'wp-chatbot-kb' ); ?></th>
				<td>
					<label>
						<input type="checkbox" name="wpckb_settings[enable_logging]" value="1" <?php checked( ! empty( $settings['enable_logging'] ) ); ?> />
						<?php esc_html_e( 'Guardar las conversaciones para revisión', 'wp-chatbot-kb' ); ?>
					</label>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="wpckb_log_retention"><?php esc_html_e( 'Retención de logs (días)', 'wp-chatbot-kb' ); ?></label></th>
				<td><input type="number" min="0" max="365" id="wpckb_log_retention" name="wpckb_settings[log_retention_days]" value="<?php echo esc_attr( (string) $settings['log_retention_days'] ); ?>" class="small-text" /></td>
			</tr>
		</table>

		<h2 class="title"><?php esc_html_e( 'Widget de chat', 'wp-chatbot-kb' ); ?></h2>
		<table class="form-table" role="presentation">
			<tr>
				<th scope="row"><?php esc_html_e( 'Mostrar widget flotante', 'wp-chatbot-kb' ); ?></th>
				<td>
					<label>
						<input type="checkbox" name="wpckb_settings[enable_widget]" value="1" <?php checked( ! empty( $settings['enable_widget'] ) ); ?> />
						<?php esc_html_e( 'Activar en todo el sitio (también puedes usar el shortcode [wpckb_chat] en cualquier página)', 'wp-chatbot-kb' ); ?>
					</label>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="wpckb_widget_title"><?php esc_html_e( 'Título del widget', 'wp-chatbot-kb' ); ?></label></th>
				<td><input type="text" id="wpckb_widget_title" name="wpckb_settings[widget_title]" class="regular-text" value="<?php echo esc_attr( $settings['widget_title'] ); ?>" /></td>
			</tr>
			<tr>
				<th scope="row"><label for="wpckb_welcome_message"><?php esc_html_e( 'Mensaje de bienvenida (castellano)', 'wp-chatbot-kb' ); ?></label></th>
				<td><input type="text" id="wpckb_welcome_message" name="wpckb_settings[welcome_message]" class="regular-text" value="<?php echo esc_attr( $settings['welcome_message'] ); ?>" />
					<p class="description"><?php esc_html_e( 'Es la frase que la mascota "dice" (por texto y voz) al saludar cuando se abre el chat.', 'wp-chatbot-kb' ); ?></p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="wpckb_welcome_message_gn"><?php esc_html_e( 'Mensaje de bienvenida (guaraní)', 'wp-chatbot-kb' ); ?></label></th>
				<td><input type="text" id="wpckb_welcome_message_gn" name="wpckb_settings[welcome_message_gn]" class="regular-text" value="<?php echo esc_attr( $settings['welcome_message_gn'] ); ?>" /></td>
			</tr>
			<tr>
				<th scope="row"><label for="wpckb_widget_color"><?php esc_html_e( 'Color principal', 'wp-chatbot-kb' ); ?></label></th>
				<td><input type="text" id="wpckb_widget_color" name="wpckb_settings[widget_color]" value="<?php echo esc_attr( $settings['widget_color'] ); ?>" class="wpckb-color-field" /></td>
			</tr>
			<tr>
				<th scope="row"><label for="wpckb_widget_position"><?php esc_html_e( 'Posición', 'wp-chatbot-kb' ); ?></label></th>
				<td>
					<select id="wpckb_widget_position" name="wpckb_settings[widget_position]">
						<option value="bottom-right" <?php selected( $settings['widget_position'], 'bottom-right' ); ?>><?php esc_html_e( 'Abajo a la derecha', 'wp-chatbot-kb' ); ?></option>
						<option value="bottom-left" <?php selected( $settings['widget_position'], 'bottom-left' ); ?>><?php esc_html_e( 'Abajo a la izquierda', 'wp-chatbot-kb' ); ?></option>
					</select>
				</td>
			</tr>
		</table>

		<h2 class="title"><?php esc_html_e( 'Idioma y voz', 'wp-chatbot-kb' ); ?></h2>
		<table class="form-table" role="presentation">
			<tr>
				<th scope="row"><label for="wpckb_default_language"><?php esc_html_e( 'Idioma por defecto', 'wp-chatbot-kb' ); ?></label></th>
				<td>
					<select id="wpckb_default_language" name="wpckb_settings[default_language]">
						<option value="es" <?php selected( $settings['default_language'], 'es' ); ?>><?php esc_html_e( 'Castellano', 'wp-chatbot-kb' ); ?></option>
						<option value="gn" <?php selected( $settings['default_language'], 'gn' ); ?>><?php esc_html_e( 'Guaraní', 'wp-chatbot-kb' ); ?></option>
					</select>
				</td>
			</tr>
			<tr>
				<th scope="row"><?php esc_html_e( 'Botón de guaraní', 'wp-chatbot-kb' ); ?></th>
				<td>
					<label>
						<input type="checkbox" name="wpckb_settings[enable_guarani]" value="1" <?php checked( ! empty( $settings['enable_guarani'] ) ); ?> />
						<?php esc_html_e( 'Mostrar el selector Castellano / Guaraní en la ventana del chat', 'wp-chatbot-kb' ); ?>
					</label>
					<p class="description"><?php esc_html_e( 'El modelo de IA responderá en el idioma elegido. Nota: el reconocimiento y la lectura en voz alta (Web Speech API del navegador) no tienen soporte confiable de guaraní; en ese idioma el asistente funcionará igualmente por texto.', 'wp-chatbot-kb' ); ?></p>
				</td>
			</tr>
			<tr>
				<th scope="row"><?php esc_html_e( 'Entrada por voz (dictado)', 'wp-chatbot-kb' ); ?></th>
				<td>
					<label>
						<input type="checkbox" name="wpckb_settings[enable_voice_input]" value="1" <?php checked( ! empty( $settings['enable_voice_input'] ) ); ?> />
						<?php esc_html_e( 'Mostrar el micrófono para dictar la pregunta por voz', 'wp-chatbot-kb' ); ?>
					</label>
				</td>
			</tr>
			<tr>
				<th scope="row"><?php esc_html_e( 'Salida por voz (lectura de respuestas)', 'wp-chatbot-kb' ); ?></th>
				<td>
					<label>
						<input type="checkbox" name="wpckb_settings[enable_voice_output]" value="1" <?php checked( ! empty( $settings['enable_voice_output'] ) ); ?> />
						<?php esc_html_e( 'Leer en voz alta las respuestas del asistente (el usuario puede silenciarlo desde el chat)', 'wp-chatbot-kb' ); ?>
					</label>
					<p class="description"><?php esc_html_e( 'Por defecto, el plugin elige automáticamente la voz en español disponible que suene más femenina y con acento neutro (preferimos variantes como "Latinoamérica"/"US" antes que acentos muy marcados). Esto depende de las voces instaladas en el dispositivo de cada visitante — no todos los celulares/PCs tienen las mismas.', 'wp-chatbot-kb' ); ?></p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="wpckb_voice_name_hint"><?php esc_html_e( 'Preferencia de voz (opcional)', 'wp-chatbot-kb' ); ?></label></th>
				<td>
					<input type="text" id="wpckb_voice_name_hint" name="wpckb_settings[voice_name_hint]" class="regular-text" value="<?php echo esc_attr( $settings['voice_name_hint'] ); ?>" placeholder="<?php esc_attr_e( 'Ej: Helena, Paulina, Google español...', 'wp-chatbot-kb' ); ?>" />
					<p class="description"><?php esc_html_e( 'Si probaste el chat en tu propia PC/celular y te gustó una voz en particular, escribí acá parte de su nombre (lo ves en la lista de voces de tu sistema operativo). El plugin la va a usar cuando esté disponible en el dispositivo del visitante, y si no, vuelve al criterio automático de arriba.', 'wp-chatbot-kb' ); ?></p>
				</td>
			</tr>
		</table>

		<h2 class="title"><?php esc_html_e( 'Mascota animada', 'wp-chatbot-kb' ); ?></h2>
		<table class="form-table" role="presentation">
			<tr>
				<th scope="row"><?php esc_html_e( 'Imagen, GIF o video del personaje', 'wp-chatbot-kb' ); ?></th>
				<td>
					<input type="hidden" id="wpckb_mascot_attachment_id" name="wpckb_settings[mascot_attachment_id]" value="<?php echo esc_attr( (string) $settings['mascot_attachment_id'] ); ?>" />
					<div id="wpckb_mascot_preview" style="margin-bottom:10px;">
						<?php if ( str_starts_with( (string) $mascot_mime, 'video/' ) ) : ?>
							<video src="<?php echo esc_url( $mascot_url ); ?>" style="width:90px;height:90px;object-fit:cover;object-position:top;border-radius:50%;" muted loop autoplay playsinline></video>
						<?php else : ?>
							<img src="<?php echo esc_url( $mascot_url ); ?>" style="width:90px;height:90px;object-fit:cover;object-position:top;border-radius:50%;" alt="" />
						<?php endif; ?>
						<?php if ( $mascot_is_default ) : ?>
							<p class="description"><?php esc_html_e( 'Usando el personaje "Lexi" incluido por defecto.', 'wp-chatbot-kb' ); ?></p>
						<?php endif; ?>
					</div>
					<button type="button" class="button" id="wpckb_mascot_select"><?php esc_html_e( 'Elegir archivo…', 'wp-chatbot-kb' ); ?></button>
					<button type="button" class="button" id="wpckb_mascot_remove" <?php echo $mascot_is_default ? 'style="display:none;"' : ''; ?>><?php esc_html_e( 'Restaurar Lexi por defecto', 'wp-chatbot-kb' ); ?></button>
					<p class="description"><?php esc_html_e( 'Admite imagen estática (PNG/SVG, idealmente con fondo transparente), GIF animado o video corto (MP4/WebM, sin sonido, en loop). Se usa como icono flotante y como avatar dentro del chat.', 'wp-chatbot-kb' ); ?></p>
				</td>
			</tr>
			<tr>
				<th scope="row"><?php esc_html_e( 'Saludo animado al abrir', 'wp-chatbot-kb' ); ?></th>
				<td>
					<label>
						<input type="checkbox" name="wpckb_settings[mascot_greet_on_open]" value="1" <?php checked( ! empty( $settings['mascot_greet_on_open'] ) ); ?> />
						<?php esc_html_e( 'Al abrir el chat por primera vez, la mascota saluda (animación + mensaje de bienvenida por texto y voz)', 'wp-chatbot-kb' ); ?>
					</label>
				</td>
			</tr>
		</table>

		<h2 class="title"><?php esc_html_e( 'Actualizaciones automáticas', 'wp-chatbot-kb' ); ?></h2>
		<table class="form-table" role="presentation">
			<tr>
				<th scope="row"><label for="wpckb_update_repo"><?php esc_html_e( 'Repositorio de GitHub', 'wp-chatbot-kb' ); ?></label></th>
				<td>
					<input type="text" id="wpckb_update_repo" name="wpckb_settings[update_repo]" class="regular-text" value="<?php echo esc_attr( $settings['update_repo'] ); ?>" placeholder="usuario-o-organizacion/nombre-repositorio" />
					<p class="description"><?php esc_html_e( 'Repositorio público de GitHub donde se publican las nuevas versiones (formato "usuario/repositorio"). Cuando haya una versión más nueva publicada ahí, va a aparecer en Plugins con el botón "Actualizar ahora", igual que cualquier otro plugin.', 'wp-chatbot-kb' ); ?></p>
				</td>
			</tr>
		</table>

		<h2 class="title"><?php esc_html_e( 'Avanzado', 'wp-chatbot-kb' ); ?></h2>
		<table class="form-table" role="presentation">
			<tr>
				<th scope="row"><?php esc_html_e( 'Al desinstalar el plugin', 'wp-chatbot-kb' ); ?></th>
				<td>
					<label>
						<input type="checkbox" name="wpckb_settings[delete_data_on_uninstall]" value="1" <?php checked( ! empty( $settings['delete_data_on_uninstall'] ) ); ?> />
						<?php esc_html_e( 'Borrar toda la base de conocimiento, ajustes y conversaciones al eliminar el plugin', 'wp-chatbot-kb' ); ?>
					</label>
					<p class="description"><?php esc_html_e( 'Déjalo desmarcado si quieres conservar los datos por si reinstalas el plugin más adelante.', 'wp-chatbot-kb' ); ?></p>
				</td>
			</tr>
		</table>

		<?php submit_button( __( 'Guardar ajustes', 'wp-chatbot-kb' ) ); ?>
	</form>
</div>
