( function () {
	'use strict';

	document.addEventListener( 'DOMContentLoaded', function () {
		var deleteLinks = document.querySelectorAll( '.wpckb-delete-link' );
		deleteLinks.forEach( function ( link ) {
			link.addEventListener( 'click', function ( event ) {
				if ( ! window.confirm( '¿Eliminar esta fuente y todos sus fragmentos de la base de conocimiento?' ) ) {
					event.preventDefault();
				}
			} );
		} );

		initMascotUploader();
	} );

	/**
	 * Selector de la mascota animada usando la librería de medios nativa de WordPress.
	 */
	function initMascotUploader() {
		var selectBtn = document.getElementById( 'wpckb_mascot_select' );
		var removeBtn = document.getElementById( 'wpckb_mascot_remove' );
		var hiddenInput = document.getElementById( 'wpckb_mascot_attachment_id' );
		var preview = document.getElementById( 'wpckb_mascot_preview' );

		if ( ! selectBtn || typeof window.wp === 'undefined' || ! window.wp.media ) {
			return;
		}

		var frame = null;

		selectBtn.addEventListener( 'click', function ( event ) {
			event.preventDefault();

			if ( frame ) {
				frame.open();
				return;
			}

			frame = window.wp.media( {
				title: 'Selecciona el personaje del asistente',
				button: { text: 'Usar este archivo' },
				library: { type: [ 'image', 'video' ] },
				multiple: false
			} );

			frame.on( 'select', function () {
				var attachment = frame.state().get( 'selection' ).first().toJSON();
				hiddenInput.value = attachment.id;

				var mime = attachment.mime || '';
				var url = attachment.url;

				if ( mime.indexOf( 'video/' ) === 0 ) {
					preview.innerHTML = '<video src="' + url + '" style="width:90px;height:90px;object-fit:cover;border-radius:50%;" muted loop autoplay playsinline></video>';
				} else {
					preview.innerHTML = '<img src="' + url + '" style="width:90px;height:90px;object-fit:cover;border-radius:50%;" alt="" />';
				}

				if ( removeBtn ) {
					removeBtn.style.display = '';
				}
			} );

			frame.open();
		} );

		if ( removeBtn ) {
			removeBtn.addEventListener( 'click', function ( event ) {
				event.preventDefault();
				hiddenInput.value = '0';
				var defaultUrl = ( typeof window.WPCKB_ADMIN !== 'undefined' ) ? window.WPCKB_ADMIN.defaultMascotUrl : '';
				preview.innerHTML = '<img src="' + defaultUrl + '" style="width:90px;height:90px;object-fit:cover;object-position:top;border-radius:50%;" alt="" /><p class="description">Usando el personaje "Lexi" incluido por defecto.</p>';
				removeBtn.style.display = 'none';
			} );
		}
	}
} )();
